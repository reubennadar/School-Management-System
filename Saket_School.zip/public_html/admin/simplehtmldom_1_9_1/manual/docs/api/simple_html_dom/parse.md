# parse (protected)

```php
parse ()
```

Parses the document. This function is called after the document was loaded into `$this->doc`.