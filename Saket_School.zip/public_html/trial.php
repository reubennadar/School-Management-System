      <div class="container py-3" id="row">
          <h1><center>Mumbai News</center></h1>
           <?php
include "simple_html_dom.php";
$dom=file_get_html('https://mumbaimirror.indiatimes.com/',false);
$ret=$dom->find('div.column2 ul',0);
//echo $ret;

foreach($ret->find('li a') as $element)
{
    $plaintext=$element->plaintext;
     $url=$element->href;
      $href="https://mumbaimirror.indiatimes.com".$url;
       $dom1=file_get_html($href);
           $img=$dom1->find('img[title]',0);
    $src=$img->src;

    

?>
          <div class="media border p-3">
    <img src="<?php echo $src;?>" alt="Mumbai Mirror" class="mr-3 mt-3 rounded-circle" style="width:60px;">
    <div class="media-body">
        <a href="https://mumbaimirror.indiatimes.com<?php echo $element->href;?>">
      <p>Mumbai Mirror <small><i></i></small></p>
      <h4><?php echo $element->plaintext;?></h4>    </a>  
    </div>
  </div>
  <?php } ?>
      </div><br>
