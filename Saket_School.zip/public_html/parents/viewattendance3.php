<html>
    
    <head></head>
    <body>
    <?php 
    include "db.php";
    
   
   $string=$_POST['month'];

$str_arr = explode (" ", $string);  
$month=$str_arr[0];
//echo $month;
$year=$str_arr[1];
$student_id=$str_arr[2];
//echo $year;
// echo $student_id;
 
    ?>
   <h1><?php echo $month.' '.$year.' Attendance'?></h1>
    <table class="table table-striped">
                            <tr>
                            <th>#Serial no</th>
                            
                            <th> Date</th>
                            <th>Attendance Status</th>
                            </tr>
                            <?php
                              
                                $counter=0;
                                
                                $result3=mysqli_query($con,"select * from attendance_records where student_id='$student_id' and monthname(Date)='$month' and year(Date)='$year' ");
                                while($rows=mysqli_fetch_array($result3))
                                {
                                    
                            ?>
                            <tr>
                            <td><?php echo $counter+1?></td>
                           
                            <td><?php echo date("d-M", strtotime($rows['Date']));?></td>
                            <?php
                            if($rows["attendance_status"] == 'P')
   {
    
  
                                 
                            ?>
                            <td ><span class="badge" style="background-color:green;color:white"><?php echo $rows['attendance_status']
                            ?></span></td>
                            <?php 
   }
   if($rows["attendance_status"] == 'A')
   {
   ?>
  
                            <td><label class="badge" style="background-color:red;color:white""><?php echo $rows['attendance_status']
                            ?></label>
                            </td>
                            <?php } ?>
                            </tr>   
                            <?php
                                $counter++;
                                }
                             
                            ?>


                        </table>
    
    
    </body>
</html>