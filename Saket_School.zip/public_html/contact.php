<?php include "header.php"?>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


include("admin/db.php");
if(isset($_POST['submit']))
{
    
    $name=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $description=$_POST['description'];
     $sql="insert into contact(name,email,subject,description)values('$name','$email','$subject','$description')";
     $result=mysqli_query($con,$sql);
$flag=0;



$mail = new PHPMailer(true);

try {
   
    $mail->setFrom('reuben.nadar99@gmail.com','Saket School');
    $mail->addAddress($email,$name);     // Add a recipient
    // $mail->addAddress('ellen@example.com');               // Name is optional
    // $mail->addReplyTo('info@example.com', 'Information');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    // Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Hello '.$name.' Thankyou for contacting Saket School';
    $mail->Body    = 'Our administrator will soon contact you';
    $mail->AltBody = '-Saket School';

    $mail->send();
    
    $success='Your request has been processed';$flag=1;
} catch (Exception $e) {
    $success=" {$mail->ErrorInfo}, Please enter proper email address";
    $flag=2;
}
    
   
}
?>
<style>
    #contactcol, #contactcol2{
        /*background-color:#291670;*/
         background-image: linear-gradient(135deg,#ea281c 0%,#291670 100%);
         color:#fff;
         border-top-left-radius:30px;
         border-bottom-left-radius:30px; 
         border-top-right-radius:30px;
         border-bottom-right-radius:30px; 
    }
   
</style>
<div style="         background-image:url();
 height:300px">
    <br>
    <br><br><br><br><br><br><br>
    <h1 style="color:#fff;" align="center">Contact us</h1>
</div>
<div class="container py-3 ">
    <div class="row py-3">
        <div class="col-sm-6 col-md-6 py-3" id="contactcol">
            <h3 align="center" style="color:white">
               Contact us to get the best education for your kids
               <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                   <div class="form-group py-3">
                       <input type="text" class="form-control" placeholder="Your name" name="name"required>
                <input type="mail" class="form-control" placeholder="Email address" name="email"required>          
                <input type="text" class="form-control " placeholder="Subject" name="subject"required>
                <textarea class="form-control" cols="30" rows="10" placeholder="What would you like to tell us" name="description" required></textarea>
                
                   </div>
                   <input type="submit" value="Submit" name="submit" class="btn btn-primary">
               </form>
            </h3>
        </div>
        <div class="col-sm-6 col-md-6 py-3">
            <div class="container py-3" id="contactcol2">
                 <h2>Address</h2>
            <p> Saket Vidyanagari Marg, Chinchpada Road, Kat emanivli, Kalyan (E), Neelkanthnagar, Kalyan, Maharashtra 421306</p>
            </div>
            <br>
            <div class="container py-3" id="contactcol2">
                 <h2>Phone No.</h2>
            <p> 0251 225 0951</p>
            </div>
            <br>
            <div class="container py-3" id="contactcol2">
                <h2>Email Address</h2>
            <p>saket.school@gmail.com</p>
            </div>
           
           
            
            
        </div>
    </div>
</div>
<div class="container-fluid" id="gmap">
    <iframe width="100%" height="500" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.4849156210116!2d73.14020141490342!3d19.21768708700675!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7944eeca56ce9%3A0x1a523a838eaa68a4!2sSAKET%20VIDYA%20MANDIR%20ENGLISH%20HIGH%20SCHOOL!5e0!3m2!1sen!2sin!4v1578604425692!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</div>

	
<?php include "footer.php"?>