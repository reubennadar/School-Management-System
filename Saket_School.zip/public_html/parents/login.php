<?php include("db.php");


session_start();
if(isset($_SESSION['$PARENT']))
{
    header("Location:student-attendance");
}
$uname=$_POST['uname'];
$psw=$_POST['psw'];
#print($uname.$psw);

if(isset($_POST['login']))
{
   #echo "success";
    $result=mysqli_query($con,"select * from students where email='$uname' and pswd='$psw'");
    // mysqli_query($con,"insert into staff values('selvi','selvi')");
    //session_start();
    
    //$_SESSION['$PARENT']=$uname;
    if(mysqli_num_rows($result)!=0)
    {
        #echo "num rows";
        $_SESSION['$PARENT']=$uname;
        header("Location:student-attendance");
    }
    else
    {
        header("Location:login");
    }
     
}
include("header.php");
?>

<style>
/*body {font-family: Arial, Helvetica, sans-serif;}*/
/*form {border: 3px solid #f1f1f1;}*/

input[type=email], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

#btn {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

#con{
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

 Change styles for span and cancel button on extra small screens 
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
<br><br><br><br><br> 
<div class="container-fluid"><br>
<br>
<h2><center style="color:white">Saket School Parent's Login Form</center></h2>
</div>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
  <div class="imgcontainer">
    <img src="https://www.w3schools.com/whatis/img_avatar1.png" alt="Avatar" class="avatar">
  </div>

  <div  id="con"class="container">
    <label for="uname"><b>Username</b></label>
    <input type="email" placeholder="Enter Username" name="uname" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>
        
    <button id="btn" type="submit"name="login">Login</button>
    
  </div>

 
</form>
<br>
<?php include("footer.php");