<?php
include("db.php");
$flag=0;
$flag2=0;
include "session.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

?>
<?php
if($_POST['submit'])
{

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
   
    $email=$_POST['email'];
    $message=$_POST['message'];
    $id=$_POST['id'];
    $subject=$_POST['subject'];
    //Recipients
    $mail->setFrom('reuben.nadar99@gmail.com', 'Saket School');
    $mail->addAddress($email,'Reply');     // Add a recipient
    
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = '';

    $mail->send();
    $m= 'Message has been sent';
    $flag=1;
    $sql="update contact set action='replied' where id='$id'";
    $result=mysqli_query($con,$sql);
} catch (Exception $e) {
    $flag=2;
    $m= "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}
?>
<?php include("header.php");?>
                   <style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}



</style>
    <br><br><br><br>
        <div class="container py-3" style="background:white">
            <div class="jumbotron"><h2 align="center">Reply to the Messages</h2></div>
            <div class="panel panel-default">
                 
        
         
         
       
                <div class="panel panel-heading">
                    <!--<div align="right">-->
                    <!-- <button type="button" id="report_button" class="btn  btn-danger btn-sm ">Report</button>-->
                    <!-- </div>-->


  


                     
                    <?php
                    if($flag==1){
                    ?>
                    <div class="alert alert-success">
                       
                <?php echo $m?>
                    </div>
                    <?php
                    }
                    ?>
 <?php
                    if($flag==2){
                    ?>
                    <div class="alert alert-danger">
                       
                <?php echo $m?>
                    </div>
                    <?php
                    }
                    ?>

                     
                    
                       <div class="table-responsive">
                        <table class="table table-striped" style="" id="myTable">
                           <tr>
        <th>Serial No</th>
        <th>Name</th>
        <th>Email</th>
        <th>Subject</th>
        <th>Description</th>
        <th>Action</th>
    </tr>
   
        <?php 
            $c=0;
            $result=mysqli_query($con,"select * from contact order by id desc ");
            while($row=mysqli_fetch_array($result))
            {
                $c++
        ?>
        <tr>
            <td><?php echo $c;?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['email'];?></td>
            <td><?php echo $row['subject'];?></td>
            <td><?php echo $row['description'];?></td>
            <td> <?php if($row['action']=='No Reply'){?>
                 <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo $c;?>">Reply</button>
                <?php }
                else{
                ?>
                 <h4><span class="label label-default">Replied</span></h4>
                 <!--<span class="btn btn-success">Replied</span>-->
                <?php } ?>
  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $c;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Reply</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
                  
              <input type="email" class="form-control" name="email" value="<?php echo $row['email'];?>">
              <input type="text" class="form-control" name="subject" placeholder="Enter your subject....">
              <textarea name="message" class="form-control" placeholder="Enter your reply..."></textarea>
              <input type="hidden" name="id" value="<?php echo $row['id'];?>">
              <input type="submit" name="submit" class="btn btn-success">
              </form>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
                
                
            </td>
        </tr>
        <?php
            }
        ?>
                        </table>
                        </div>
    
                </div>

                </div>
                
                            
                
            </div>
        </div>
       
<br>
   <?php include "footer.php";?>