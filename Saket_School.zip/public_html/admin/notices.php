<?php include("db.php");
   include("session.php");
   include("header.php");
   
   
   
   if(isset($_POST['del']))
   {
       $notice_id=$_POST['notice_id'];
       $sql="delete from notices where notice_id='$notice_id'";
       $result=mysqli_query($con,$sql);
       if($result){
           $flag=5;
       }
       
       else
       {
           $flag=3;
       }
   }
   if(isset($_POST['update']))
   {
       
       
   $title=$_POST['title'];
   $description=$_POST['description'];
  
   $notice_id=$_POST['notice_id'];
 
      $update="inside no wala";
         $sql="update notices set title='$title',description='$description' where notice_id='$notice_id'";
    //$sql="update notice set title='$title' where notice_id='$notice_id'";
    $result=mysqli_query($con, $sql);
    if($result)
    {
        $flag=2;
    }
    
 
   
  
   if($flag==2)
   {
    //   echo "data updated successfully";
   }
   else
   {
    //   echo "Data not inserted";
       $flag=3;
   }
  
   }
   if(isset($_POST["submit"])) {
   
   $title=$_POST['title'];
   $description=$_POST['description'];
    
   $flag=0;
 
       $result=mysqli_query($con,"insert into notices (title,description) values('$title','$description')");
       //  $result= mysqli_query($con,"insert into updates values('Event-2','Hello everyone','1999-12-09','img.jpg')");
       if($result)
       {
           $flag=1;
       }
   
  
   if($flag==1)
   {
       echo" data inserted successfully";
   }
   else if($flag==2)
   {
       echo "data updated successfully";
   }
   else
   {
       echo "Data not inserted";
       $flag=3;
   }
      
   
   }
   
   ?>
<?php ?>
<br>
<br><br><br><br>
<br>
<div class="container py-3" style="background:white">
   <div class="jumbotron">
      <h2 align="center">Add Notices</h2>
   </div>

   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaladd">
   +Add
   </button>

   
      <?php if($flag==1){?>
      <div class="alert alert-success">
         <strong> Success! </strong>Notice added successfully
      </div>
      <?php }?>
      
         <?php if($flag==2){?>
         <div class="alert alert-success">
            <strong> Success! </strong>Notice updated successfully
         </div>
         <?php }?>
         
            <?php if($flag==5){?>
            <div class="alert alert-danger">
               <strong> Yeahh!! </strong>Notice deleted successfully!!
            </div>
            <?php }?>
            
               <?php if($flag==3){?>
               <div class="alert alert-danger">
                  <strong> Error! </strong>Something went Wrong!!
               </div>
               <?php }?>
            
            <!-- The Modal -->
            <div class="modal fade" id="myModaladd">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <!-- Modal Header -->
                     <div class="modal-header">
                        <h4 class="modal-title">Add Notices</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>
                     <!-- Modal body -->
                     <div class="modal-body">
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                           <div class="form-group">
                              
                             
                              <label>Title</label><input type="text" class="form-control"name="title">
                              <label>Description</label><textarea class="form-control" name="description"></textarea>
                             
                              
                           </div>
                           <div class="form-group">
                              <center> <input type="submit" value="submit" class=" btn btn-success" name="submit"></center>
                           </div>
                        </form>
                     </div>
                     <!-- Modal footer -->
                     <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                     </div>
                  </div>
               </div>
            </div>
            <div class="panel panel-body table-responsive" style="overflow-x:auto;">
               <table class="table table-striped">
                  <tr>
                      
                     <th>Title</th>
                     <th>Description</th>
                     <th>Action</th>
                  </tr>
                  <?php
                     $sql="select * from notices order by date desc";
                     $result=mysqli_query($con,$sql);
                     $c=0;
                     while($row=mysqli_fetch_array($result))
                     {
                         $c++;
                     
                     ?>
                  <tr>
                     
                    
                     <td><?php echo $row['title'];?></td>
                     <td><?php echo $row['description'];?></td>
                    
                     <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaledit<?php echo $c?>">
                        Edit
                        </button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $c?>">
                        Del
                        </button>
                     </td>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaledit<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Update Notices Details</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                                    <div class="form-group">
                                        
                                       <label>Title</label><input type="text" class="form-control"name="title" value="<?php echo $row['title'];?>">
                                       <label>Description</label><input type="text"class="form-control" name="description" value="<?php echo $row['description'];?>">
                                      
                                       
                                       <input type="hidden" name="notice_id" value="<?php echo $row['notice_id'];?>">
                                    </div>
                                    <div class="form-group">
                                       <center> <input type="submit" value="Update" class=" btn btn-success" name="update"></center>
                                    </div>
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaldel<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Are you sure you want to delete this Notice??</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="" method="post">
                                    <input type="hidden" name="notice_id" value="<?php echo $row['notice_id'];?>">
                                    <input type="submit" value="del" name="del" class="btn btn-danger" >
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </tr>
                  <?php
                     }
                     ?>
               </table>
            </div>
         </div>
<!--      </div>-->
<!--   </div>-->
<!--</div>--><br>
<?php
   if($_POST['update'])
   {
    //   echo $notice_id;
    //   echo $title;
    //   echo $description;
    //   echo $image;
    //   echo $_FILES["fileToUpload"]["name"];
    //   echo " ".$update;
   }
   ?>
<?php include"footer.php";
   ?>