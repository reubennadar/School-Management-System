      <!-- Footer -->
      <br>
      <footer class="page-footer font-small mdb-color lighten-3 pt-4"id="footer">
         <!-- Footer Links -->
         <div class="container text-center text-md-left">
            <!-- Grid row -->
            <div class="row">
               <!-- Grid column -->
               <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">
                  <!-- Content -->
                  <h5 class="font-weight-bold text-uppercase mb-4">About us</h5>
                  <p>We are one of the oldest Educational School of Kalyan and we are known as Yoga University.We build our students with bricks of social interaction, cultural activities, confidence, communication skills and last not the least with Love </p>
                  <!--<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit amet numquam iure provident voluptate-->
                  <!--   esse-->
                  <!--   quasi, veritatis totam voluptas nostrum.-->
                  <!--</p>-->
               </div>
               <!-- Grid column -->
               <hr class="clearfix w-100 d-md-none">
               <!-- Grid column -->
               <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">
                  <!-- Links -->
                  <h5 class="font-weight-bold text-uppercase mb-4">Important Links</h5>
                  <ul class="list-unstyled" style="color:white">
                      <li>
                        <p>
                           <a href="../home">HOME</a>
                        </p>
                     </li>
                     <li>
                        <p>
                           <a href="../gallery">GALLERY</a>
                        </p>
                     </li>
                     <li>
                        <p>
                           <a href="../contact">CONTACT US</a>
                        </p>
                     </li>
                  </ul>
               </div>
               <!-- Grid column -->
               <hr class="clearfix w-100 d-md-none">
               <!-- Grid column -->
               <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">
                  <!-- Contact details -->
                  <h5 class="font-weight-bold text-uppercase mb-4">Address</h5>
                  <ul class="list-unstyled">
                     <li>
                        <p>
                           <i class="fas fa-home mr-3"></i> Saket Vidyanagari Marg, Chinchpada Road, Kat emanivli, Kalyan (E), Neelkanthnagar, Kalyan, Maharashtra 421306
                        </p>
                     </li>
                     <li>
                        <p>
                           <i class="fas fa-envelope mr-3"></i> saket.school@gmail.com
                        </p>
                     </li>
                     <li>
                        <p>
                           <i class="fas fa-phone mr-3"></i>0251 225 0951

                        </p>
                     </li>
                     <li>
                        <p>
                           <i class="fas fa-print mr-3"></i> + 01 234 567 89
                        </p>
                     </li>
                  </ul>
               </div>
               <!-- Grid column -->
               <hr class="clearfix w-100 d-md-none">
               <!-- Grid column -->
               <div class="col-md-2 col-lg-2 text-center mx-auto my-4"style=" ">
                  <!-- Social buttons -->
                  <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>
                  <!-- Facebook -->
                  <a type="" class="btn-floating btn-fb">
                  <i class="fab fa-facebook" style="color:#fff; font-size:48px;"></i>
                  </a><br>
                  <!-- Twitter -->
                  <a type="" class="btn-floating btn-tw"style="color:#fff; font-size:48px">
                  <i class="fab fa-twitter"></i>
                  </a><br>
                  <!-- Google +-->
                  <a type="" class="btn-floating btn-gplus"style="color:#fff; font-size:48px">
                  <i class="fab fa-google-plus-g"></i>
                  </a><br>
                  <!-- Dribbble -->
                  <a type="" class="btn-floating btn-dribbble"style="color:#fff; font-size:48px">
                  <i class="fab fa-instagram"></i>
                  </a><br><br>
               </div>
               <!-- Grid column -->
            </div>
            <!-- Grid row -->
         </div>
         <!-- Footer Links -->
         <!-- Copyright -->
         <div class="footer-copyright text-center py-3">© 2020 Copyright:
            <a href="../home"> SaketSchool.com</a>
         </div>
         <!-- Copyright -->
      </footer>
      <!-- Footer -->
     
   </body>
</html>