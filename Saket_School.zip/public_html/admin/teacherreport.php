<?php

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html='<html><head>
                <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
                </head><body><h1 align="center">Teachers Records of Saket Vidya Mandir</h1>';

$html.='<h3 align="center">'.$std." ".$from." to".$to.'</h3>';

include("db.php");
// if(isset($std,$from,$to))
// {
    $result=mysqli_query($con,"select * from teachers");
     $html.='
                <table class="table">
                <tr>
                <th>Uid</th>
                <th>Std</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Password</th>
                ';
                
    $html.='</tr>
            ';
            
   
    while($row=mysqli_fetch_array($result))
    {
        $uid=$row['uid'];
        $std=$row['std'];
        $name=$row['name'];
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
        $html.='<tr>
            <td>'.$uid.'</td>
            <td>'.$std.'</td>
        <td>'.$name.'</td>
        
        <td>'.$phone.'</td>
        <td>'.$email.'</td>
        <td>'.$pswd.'</td>';
      
        $html.='</tr>';
    }
        $html.='</table></body></html>';
// }
$dompdf=new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','Portrait');
$dompdf->render();
$dompdf->stream('Teacher Report',array("Attachement"=>0));
?>




