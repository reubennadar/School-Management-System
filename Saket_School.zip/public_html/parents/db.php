<?php 
$con=mysqli_connect("localhost","id11184380_admin","admin","id11184380_attendance");

?>