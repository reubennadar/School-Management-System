<?php 
include("db.php");
session_start();
 
if(!isset($_SESSION['$USER']))
{
    header("Location:login.php");    
}
include "header.php";
echo $_SESSION['$USER'];
    $flag=0;
    if(isset($_POST['add']))
    {
        echo "inside add";
        $result=mysqli_query($con,"select * from teachers where std='$_POST[std]' and uid='$_POST[uid]'");
        if(!mysqli_num_rows($result))
        {
            echo "inside num rows";
        $result=mysqli_query($con,"insert into teachers(uid,std,name,phone,email,pswd)values('$_POST[uid]','$_POST[std]','$_POST[name]','$_POST[phone]','$_POST[email]','$_POST[pswd]')");
        if($result)
        {
             $flag=1;
        }
       
        }
        else
        {
            $result=mysqli_query($con,"update teachers set name='$_POST[name]',std='$_POST[std]',phone='$_POST[phone]',email='$_POST[email]',pswd='$_POST[pswd]' where std='$_POST[std]' and uid='$_POST[uid]'");
            if($result)
            {
                $flag=2;
            }
         
        }
    }
    if(isset($_POST['update']))
    {
         
    }
    if(isset($_POST['search']))
    {
        $result=mysqli_query($con,"select * from teachers where std='$_POST[std]' and uid='$_POST[uid]' ");
        while($row=mysqli_fetch_array($result))
        {
        $name=$row['name'];
        $uid=$row['uid'];
        $std=$row['std'];
        
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
        }
        $flag=3;
    }
     
    if(isset($_POST['del']))
    {
        $result=mysqli_query($con,"delete from teachers where std='$_POST[std]' and uid='$_POST[uid]' ");
         
        $flag=4;
    }
       
?>
<br><br><br><br>
        <div class="container">
            <div class="jumbotron"><h2 align="center">Teacher's Registration</h2></div>
            <div class="panel panel-default">
            <?php if($flag==1){?>
            <div class="alert alert-success">
                <strong> Success! </strong>student added successfully
            </div>    
            <?php }?>
            <?php if($flag==2){?>
            <div class="alert alert-success">
                <strong> Success! </strong>student updated successfully
            </div>    
            <?php }?>
            <?php if($flag==3){?>
            <div class="alert alert-success">
                <strong> Success! </strong>student searched successfully
            </div>    
            <?php }?>
            <?php if($flag==4){?>
            <div class="alert alert-success">
                <strong> Success! </strong>student deleted successfully
            </div>    
            <?php }?>
            <!--<div class="panel-heading">-->
            <!--    <h2>-->
                
                <!--<a class="btn btn-info pull-right"href="db_index.php">Back</a>-->
                
                    
            <!--    </h2>-->
            <!--</div>-->
        </div>
       
        <div class="panel panel-body">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="form-group">
                    <label for="uid">UID</label>
                    <input type="number"name="uid" id="uid"  value="<?php echo $uid;?>"class="form-control" required>
                </div>
               
                 <div class="form-group">
                    <label for="std">Assigned Standard</label>
                    <select class="form-control" name="std" id="std"  required>
                        <option value="<?php echo $std;?>"><?php echo $std;?></option>
                        <option value="Tuition">Tuition</option>
                        <option value="1">1</option>
                         <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                       

                    </select>
                   
                </div>
               
                 <div class="form-group">
                    <label for="name">Teacher's Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
               
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone" id="phone"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email"name="email" id="email"  value="<?php echo $email;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>
                <div class="form-group">
                    
                    <input type="submit"name="add" id="submit" class="btn btn-primary"value="Add" >
                    
                    <input type="submit"name="search" id="search" class="btn btn-primary"value="Search" >
                    <input type="submit"name="del" id="del" class="btn btn-primary"value="delete" >
                </div>
            </form>
        </div>
        </div>
        <?php
    
    
              include("footer.php");
               ?>
        
  