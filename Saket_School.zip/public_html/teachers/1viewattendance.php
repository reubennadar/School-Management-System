<?php
include("db.php");
$flag=0;
$flag2=0;
session_start();
if(!isset($_SESSION['$TEACHER']))
{
    header("Location:login.php");    
}
if(isset($_POST['logout'])){
    session_destroy();
}
 $email=$_SESSION['$TEACHER'];
                                $result=mysqli_query($con,"select * from teachers where email='$email'");
                                while($row=mysqli_fetch_array($result))
                                {
                                    $std=$row['std'];
                                }
?>
<?php include("header.php");?>
            <script>
          $(document).ready(function(){
              $("#search").click(function(){
$("#myTable tr").each(function () {       
     if ($(this).find("table td:eq(3)").text() == "a") {
         $(this).css("background":"red");    
  }
 
});
});
        </script>
            <style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}


/* starts filter search*/
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
/*ends filter search*/
</style>
    <br><br><br><br>
        <div class="container py-3" style="background:white">
            <div class="jumbotron"><h2 align="center">View Student's Attendance</h2></div>
            <div class="panel panel-default">
                <div class="panel panel-heading">
                    <h2>
                    
                    
                    </h2>
                    <?php
                    if($flag){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  inserted successfully
                    </div>
                    <?php
                    }
                    ?>
                    <?php
                    if($flag2){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  Updated successfully
                    </div>
                    <?php
                    }
                    ?>
                     <?php 
                     //echo date("Y-m-d");
                     ?>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                       
                    From: <input type="date" id="startdate"  class="form-control"name="startdate">
                    To: <input type="date" id="enddate"class="form-control" name="enddate">
                        
                        <button  value="submit" id="search"name="submit"class="btn btn-info center-block">search</button>
                    </form>
                    
                    <?php if(isset($_POST['submit'])){
                    $result1=mysqli_query($con,"select distinct(Date) from attendance_records where  Date between '$_POST[startdate]' and '$_POST[enddate]' order by Date desc");

                    }?>
                    <br>
                        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
                                    <div class="panel panel-body" style="overflow-x:auto;">
                        <table class="table table-striped" id="myTable">
                            <tr>
                            <th>#Serial no</th>
                            <th>Student Name</th>
                            <th> Roll No</th>
                            <?php while($row=mysqli_fetch_array($result1)){?>
                            <th><?php echo $row['Date']?></th>
                            <?php }?>
                            </tr>
                            <?php
                              //if(isset($_POST['info']))  
                              //{
                              
                                $counter=0;
                               
                                #echo $std;
                                
                                $date=$_POST['cdate'];
                                
                                // echo $date;
                                
                                //echo $count."is the count available";
                                $result=mysqli_query($con,"select * from students where std='$std' ");
                                while($row=mysqli_fetch_array($result))
                                {
                                
                                    
                            ?>
                            <tr>
                                
                            <td><?php echo $counter+1?></td>
                            <?php 
                                $n=array($row['name']);
                                $m=array_combine($m,$n);
                                
                                ?>
                            
                            <td><?php $name=$row['name']; echo $name;?></td>
                            <td><?php $rollno=$row['rollno']; echo $rollno;?></td>
                            
                              
                            <?php
                                $counter++;
                                
                             
                            ?>
                            <?php 
                                    $student_id=$std."_".$rollno;
                                   $result2=mysqli_query($con,"select distinct(Date),attendance_status from attendance_records where student_id='$student_id' and Date between '$_POST[startdate]' and '$_POST[enddate]' order by Date desc");
                                    #$result2=mysqli_query($con,"select distinct(Date), attendance_status from attendance_records full outer join on attendance_records.std=attendance.std and attendance_records.rollno=attendance.rollno order by attendance_records.Date ");
                                 while($row=mysqli_fetch_array($result2)){
                                    //  echo "inside result1";
                                     //echo $rollno;
                                    // echo $_POST['std'];
                                     
                                    
                                 
                            ?>
                            <?php
                            if($row["attendance_status"] == 'P')
   {
    
  
                                 
                            ?>
                            <td ><span class="badge" style="background-color:green;color:white"><?php echo $row['attendance_status']
                            ?></span></td>
                            <?php 
   }
   if($row["attendance_status"] == 'A')
   {
   ?>
  
                            <td><label class="badge" style="background-color:red;color:white""><?php echo $row['attendance_status']
                            ?></label>
                            </td>
                            <?php } ?>                         
                            <?php }}?>

                            </tr>
                        </table>
    
                </div>

                </div>
                
                            
                
            </div>
        </div>
        
        <script>
        

function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<!--<p id="p">kya yaar</p>-->
   <?php include "footer.php";?>