<?php include "header.php";
include "admin/db.php";?>

      <div class="donotshow">
         <br><br><br><br><br>
      </div>
      <div id="demo" class="carousel slide" style="display:block" data-ride="carousel">
         <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
         </ul>
         <div class="carousel-inner">
            <div class="carousel-item active">
               <img src="img/slider.png" alt="Welcome" width="1100" height="500">
               <div class="carousel-caption">
                  <h3>Welcome to Saket Vidya Mandir</h3>
                  <p>We are known as Yoga Institution</p>
               </div>
            </div>
            <div class="carousel-item">
               <img src="img/slider.png" alt="Welcome" width="1100" height="500">
               <div class="carousel-caption">
                  <h3>Welcome to Saket Vidya Mandir</h3>
                  <p>Best Extracurriculum</p>
               </div>
            </div>
            <div class="carousel-item">
               <img src="img/slider.png" alt="New York" width="1100" height="500">
               <div class="carousel-caption">
                  <h3>Welcome to Saket Vidya Mandir</h3>
                  <p>We give the best education to student to learn discipline</p>
               </div>
            </div>
         </div>
         <a class="carousel-control-prev" href="#demo" data-slide="prev">
         <span class="carousel-control-prev-icon"></span>
         </a>
         <a class="carousel-control-next" href="#demo" data-slide="next">
         <span class="carousel-control-next-icon"></span>
         </a>
      </div>
      <div class="show">
         <br>
      </div>
      <div class="container">
         <div class="row" id="row">
            <div class="col-lg-6 col-sm-6 col-md-6" id="aboutus">
               <div class="container text-center">
                  <br>
                  <h1>About us</h1>
                  <p>We are one of the oldest Educational School of Kalyan and we are known as Yoga University.We build our students with bricks of social interaction, cultural activities, confidence, communication skills and last not the least with Love</p>
               </div>
               <br>
            </div>
            <div class="col-lg-6 col-sm-6 col-md-6"id="notices">
               <div class="text-center" >
                  <br>
                  <h1>Notices</h1>
               </div>
               <script>
$(document).ready(function(){
 $('#0').addClass('active');
 
});
   
</script>

<div id="demo2" class="carousel slide" style="display:block" data-ride="carousel">
    <?php 
    $result=mysqli_query($con,"select * from notices order by notice_id desc");
    if($result)
    {
        $count=0;
    ?>
    <ul class="carousel-indicators">
    <?php
        while($row=mysqli_fetch_array($result))
        { 
            
        ?>
        
                    
                     <li data-target="#demo2" data-slide-to="<?php echo $count;?>" id="<?php $count;?>"></li>
                     
        
        
        
        <?php
        $count++;
        }
        ?>
        </ul>
        <div class="carousel-inner">
        <?php
        $count=0;
        $result=mysqli_query($con,"select * from notices order by notice_id desc");
         while($row=mysqli_fetch_array($result))
        { 
            echo $count;
        ?>
         
                     <div class="carousel-item" id="<?php echo $count;?>">
                        <img src="https://thumbs.dreamstime.com/t/green-black-board-school-blackboard-2-3-10164014.jpg" alt="Welcome" width="1100" height="500">
                        <div class="carousel-caption">
                           <h3><?php echo $row['title'];?></h3>
                           <p><?php echo $row['description'];?></p>
                        </div>
         </div>
        
        
        
        <?php
         $count++;
        }
        ?>
        
    <?php
    }
    ?>
                  
                  
                  <a class="carousel-control-prev" href="#demo2" data-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                  </a>
                  <a class="carousel-control-next" href="#demo2" data-slide="next">
                  <span class="carousel-control-next-icon"></span>
                  </a>
               </div>
               <br> 
            </div>
         </div>
      </div>
      </div>
      <br>
      <div class="container">
         <div class="row">
            <div class="col-sm-3 col-md-3 col-lg-3">
               <div class="card">
                  <div class="card-body text-center">
                     <div class="card-text">
                        <p><i class="fa fa-user"></i></p>
                        <h3>11+</h3>
                        <p>Partners</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3">
               <div class="card">
                  <div class="card-body text-center">
                     <div class="card-text">
                        <p><i class="fa fa-check"></i></p>
                        <h3>55+</h3>
                        <p>Projects</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3">
               <div class="card">
                  <div class="card-body text-center">
                     <div class="card-text">
                        <p><i class="fa fa-smile-o"></i></p>
                        <h3>100+</h3>
                        <p>Happy Clients</p>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-sm-3 col-md-3 col-lg-3">
               <div class="card">
                  <div class="card-body text-center">
                     <div class="card-text">
                        <p><i class="fa fa-coffee"></i></p>
                        <h3>100+</h3>
                        <p>Meetings</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="container">
         <div class="row">
            <div class="col-sm-6 col-md-6 col-xl-6">
               <br>
               <h1 align="center" style="color:#fff;">Hall of Fame</h1>
              <script>
$(document).ready(function(){
 $('#achiever0').addClass('active');
 
});
   
</script>

<div id="demo3" class="carousel slide" style="display:block" data-ride="carousel">
    <?php 
    $result=mysqli_query($con,"select * from achievers order by achievers_id desc limit 3");
    if($result)
    {
        $count=0;
    ?>
    <ul class="carousel-indicators">
    <?php
        while($row=mysqli_fetch_array($result))
        { 
            // echo $count;
        ?>
        
                    
                     <li data-target="#demo3" data-slide-to="<?php echo $count;?>" id="achiever<?php $count;?>"></li>
                     
        
        
        
        <?php
        $count++;
        }
        ?>
        </ul>
        <div class="carousel-inner">
        <?php
        $count=0;
        $result=mysqli_query($con,"select * from achievers order by achievers_id desc limit 3");
         while($row=mysqli_fetch_array($result))
        { 
            // echo $count;
        ?>
         
                     <div class="carousel-item" id="achiever<?php echo $count;?>">
                        <div class="card" align="center" style="width: 14rem;">
                           <img class="card-img-top" src="admin/uploads/<?php echo $row['image']; ?>" style="width:100%">
                           <div class="card-body">
                              <h4 class="card-title"><?php echo $row['title'];?></h4>
                              <?php $result2=mysqli_query($con,"select * from attendance where student_id='$row[student_id]'");
                              while($rows=mysqli_fetch_array($result2))
                              {
                                  $name=$rows['name'];
                                  $std=$rows['std'];
                              }
                              ?>
                              <h3 class="card-text"><?php echo $name;?></h3>
                              <p class="card-text"><?php echo $row['description'];?></p>
                              <!--<a href="#" class="btn btn-primary">See Profile</a>-->
                           </div>
                        </div>
         </div>
        
        
        
        <?php
         $count++;
        }
        ?>
        </div>
    <?php
    }
    ?>
                  
                  
               <!-- Left and right controls -->
                  <a class="carousel-control-prev" href="#demo3" data-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                  </a>
                  <a class="carousel-control-next" href="#demo3" data-slide="next">
                  <span class="carousel-control-next-icon"></span>
                  </a>
               </div>
            </div>
            <div class="col-sm-6 col-md-6 col-xl-6">
               <br>
               <h1 align="center" style="color:#fff">Testimonials</h1>
               <div id="myCarousel" class="carousel slide" data-ride="carousel">
                  <!-- Carousel indicators -->
                  <ol class="carousel-indicators">
                     <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                     <li data-target="#myCarousel" data-slide-to="1"></li>
                     <li data-target="#myCarousel" data-slide-to="2"></li>
                  </ol>
                  <!-- Wrapper for carousel items -->
                  <div class="carousel-inner">
                     <div class="item carousel-item active">
                        <div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar.png" alt=""></div>
                        <p class="testimonial">I am a parent. I never had to teach my kids as teahcers of SAKET school teach the kids very well.</p>
                        <p class="overview"><b>Paula Wilson</b>, Media Analyst</p>
                     </div>
                     <div class="item carousel-item">
                        <div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar2.png" alt=""></div>
                        <p class="testimonial">I am a student. I have handson computer experience due to the practical teaching given by our teacher of SAKET</p>
                        <p class="overview"><b>Antonio Moreno</b>, Web Developer</p>
                     </div>
                     <div class="item carousel-item">
                        <div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar2.png" alt=""></div>
                        <p class="testimonial">I am a teacher. SAKET loves students and teachers. Helps those students who can't afford to pay fees.</p>
                        <p class="overview"><b>Michael Holz</b>, Teacher</p>
                     </div>
                  </div>
                  <!-- Carousel controls -->
                  <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                  <i class="fa fa-angle-left"></i>
                  </a>
                  <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                  <i class="fa fa-angle-right"></i>
                  </a>
               </div>
            </div>
         </div>
      </div>
      <div class="container">
         <br>
         <h1 align="center" style="color:#fff">Extracurricular Activities</h1>
         <br>
         <div class="row text-center">
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <!-- To add FontAwesome Icons use Unicode characters and to set size use font-size instead of fa-*x because when calculating the height (see js), the size of the icon is not calculated if using classes -->
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Karate</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://storage.needpix.com/rsynced_images/karate-3615008_1280.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Every Saturday 8am to 10.30 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Western Dance</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Break_Dancer.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Every Saturday 8am to 10.30 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Classical Dance</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://clipartstation.com/wp-content/uploads/2017/11/classical-dance-clipart-black-and-white.jpg" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Every Saturday 8am to 10.30 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Singing</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/4/46/Singer_icon_transparent.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Every Saturday 8am to 10.30 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Drawing</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://cdn3.iconfinder.com/data/icons/miscellaneous-17-solid/128/hobby_creative_artist_easel_painting_drawing_sketch-512.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Every Saturday 8am to 10.30 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 card-container">
               <div class="card card-flip">
                  <div class="front card-block">
                     <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
                     <h4 class="card-title" id="fronttitle">Yoga and Exercise</h4>
                     <h6 class="card-subtitle text-muted">
                        <img src="https://svgsilh.com/svg_v2/2029429.svg" class="img-fluid img-thumbnail"style="width:50%;height:50%">
                     </h6>
                     <p class="card-text">Front Text</p>
                  </div>
                  <div class="back card-block">
                     <br>
                     <p>
                        Monday to Friday at 8 am
                     </p>
                     <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
            <div class="container py-3" id="row">
          <h1><center>Mumbai News</center></h1>
           <?php
include "simple_html_dom.php";
$dom=file_get_html('https://mumbaimirror.indiatimes.com/',false);
$ret=$dom->find('div.column2 ul',0);
//echo $ret;

foreach($ret->find('li a') as $element)
{
    $plaintext=$element->plaintext;
     $url=$element->href;
      $href="https://mumbaimirror.indiatimes.com".$url;
       $dom1=file_get_html($href);
           $img=$dom1->find('img[title]',0);
    $src=$img->src;

    

?>
          <div class="media border p-3">
    <img src="<?php echo $src;?>" alt="Mumbai Mirror" class="mr-3 mt-3 rounded-circle" style="width:60px;">
    <div class="media-body">
        <a href="https://mumbaimirror.indiatimes.com<?php echo $element->href;?>">
      <p>Mumbai Mirror <small><i></i></small></p>
      <h4><?php echo $element->plaintext;?></h4>    </a>  
    </div>
  </div>
  <?php } ?>
      </div><br>

<?php include "footer.php"?>