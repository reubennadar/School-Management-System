<?php

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html='<html><head>
                <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
                </head><body><h1 align="center">Attendance Records of Saket Vidya Mandir</h1>';
$std=$_POST['std'];
$month=$_POST['month'];
$html.='<h3 align="center">'.$std." ".$month.'</h3>';

include("db.php");
// if(isset($std,$from,$to))
// {
    $result=mysqli_query($con,"select distinct(Date) from attendance_records where Month(Date)=$month");
    $total=mysqli_num_rows($result);
    // $html.="The total number of dates are".$total;
     $start=1;
    $limit=15;
    $b=0;
    $c=2;
    $a=$total;
while($total)
{
    //  $html.="inside while loop";
    //  if(a<=0)
    //     {
            
    //         $b=$b-15+$limit;
            
    //     }
     $html.='
                <table class="table">
                <tr>
                <th>Rollno</th>
                <th>Name</th>';
     $result=mysqli_query($con,"select distinct(Date) from attendance_records where  Month(Date)=$month limit  $limit OFFSET $start");

    while($row=mysqli_fetch_array($result))
    {
        $date=date("d-M",strtotime($row['Date']));
     $html.='<th>'.$date.'</th>';
                
                
    }
    $html.='</tr>
            ';
            
    $result1=mysqli_query($con,"select * from students where std='$std'  ");
    while($row=mysqli_fetch_array($result1))
    {
        
        $rollno=$row['rollno'];
        $name=$row['name'];
        $student_id=$std."_".$rollno;
        $html.='<tr>
            <td>'.$rollno.'</td>
        <td>'.$name.'</td>';
       $result2=mysqli_query($con,"select distinct(Date),attendance_status from attendance_records where student_id='$student_id' and Month(Date)=$month limit $limit OFFSET $start  ");
       while($rw=mysqli_fetch_array($result2))
       {
           $status=$rw['attendance_status'];
           $html.='<td>'.$status.'</td>';
       }
        $html.='</tr>';
    }
        $html.='</table>';
         $total=$total-15;
        $start=$start+15;
        $b=$b+15;
        $c=$c-1;
        if($total<0)
        {
            $total=0;
        }
        
	
        
}
$html.='</body></html>';
$dompdf=new Dompdf();
$dompdf->loadHtml($html); 
$dompdf->setPaper('A4','Landscape');
$dompdf->render();
$dompdf->stream(' Monthly Attendance Records',array("Attachement"=>0));

?>




