<?php
header("Location:login");
?>