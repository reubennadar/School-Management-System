<?php include "header.php"?>
<style>
    .

</style>
<div style="         background-image:url();
 height:300px">
    <br>
    <br><br><br><br><br><br><br>
    <h1 style="color:#fff;" align="center">Gallery</h1>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-4 col-md-4 pt-3">
            <img src="https://content3.jdmagicbox.com/comp/thane/l2/022pxx22.xx22.171130122204.p6l2/catalogue/saket-college-of-arts-kalyan-thane-colleges-6oo02r5756.jpg" class="img-fluid img-thumbnail">
        </div>
        <div class="col-sm-4 col-md-4 pt-3">
            <img src="https://content3.jdmagicbox.com/comp/thane/l2/022pxx22.xx22.171130122204.p6l2/catalogue/saket-college-of-arts-kalyan-thane-colleges-6oo02r5756.jpg" class="img-fluid img-thumbnail">
        </div>
        <div class="col-sm-4 col-md-4 pt-3">
            <img src="https://content3.jdmagicbox.com/comp/thane/l2/022pxx22.xx22.171130122204.p6l2/catalogue/saket-college-of-arts-kalyan-thane-colleges-6oo02r5756.jpg" class="img-fluid img-thumbnail">
        </div>
        <div class="col-sm-4 col-md-4 pt-3">
            <img src="https://content3.jdmagicbox.com/comp/thane/l2/022pxx22.xx22.171130122204.p6l2/catalogue/saket-college-of-arts-kalyan-thane-colleges-6oo02r5756.jpg" class="img-fluid img-thumbnail">
        </div>
    </div>
</div>
<?php include "footer.php"?>