<?php
session_start();
if(!isset($_SESSION['$TEACHER']))
{
    header("Location:login");    
}
else
{
    $email=$_SESSION['$TEACHER'];
                                $result=mysqli_query($con,"select * from teachers where email='$email'");
                                while($row=mysqli_fetch_array($result))
                                {
                                    $std=$row['std'];
                                }
}

?>
