<?php
include("session.php");
include("db.php");
incude("header");
?>

<?php
include("footer.php");
?>