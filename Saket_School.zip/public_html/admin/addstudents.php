<?php 
include("db.php");

include("session.php");
include "header.php";


echo $_SESSION['$USER'];
    $flag=0;
    $student_id=$_POST['std'].'_'.$_POST['roll'];
    if(isset($_POST['add']))
    {
        echo $student_id;
        $result=mysqli_query($con,"select * from students where std='$_POST[std]' and rollno='$_POST[roll]'");
        if(!mysqli_num_rows($result))
        {
        $result=mysqli_query($con,"insert into students values('$student_id','$_POST[std]','$_POST[roll]','$_POST[name]','$_POST[father]','$_POST[mother]','$_POST[phone]','$_POST[email]','$_POST[pswd]')");
        if($result){
            echo "inside insert if";
        $result1=mysqli_query($con,"select distinct(Date) from attendance_records where  not rollno='$_POST[roll]'and  std='$_POST[std]'");
        
       
        while($row=mysqli_fetch_array($result1))
        {
            echo "inside while";

           $date=$row['Date'];
            $result2=mysqli_query($con,"insert into attendance_records values('$date','$_POST[std]','$_POST[roll]','$_POST[name]','A')");
            
           
        }
        $result3=mysqli_query($con,"select * from parents where email='$_POST[email]'");
         if(mysqli_num_rows($result3)!=null){
            $result4=mysqli_query($con,"insert into parents values('$_POST[email]','$_POST[pswd]')");
            }
            else
            {
                 $result4=mysqli_query($con,"update parents set pswd='$_POST[pswd]' where email='$_POST[email]'");
            }
        }
       if($result4){
           $flag=1;
       }
       else
       {
           $flag=6;
       }
        }
        else
        {
            $result=mysqli_query($con,"update students set  student_id='$student_id',name='$_POST[name]',father='$_POST[father]',mother='$_POST[mother]',phone='$_POST[phone]',email='$_POST[email]',pswd='$_POST[pswd]' where std='$_POST[std]' and rollno='$_POST[roll]' ");
          if(!mysqli_num_rows($result))
          {
              $result3=mysqli_query($con,"select * from parents where email='$_POST[email]'");
              if($result3==null){
                $result4=mysqli_query($con,"insert into parents values('$_POST[email]','$_POST[pswd]')");

              }
              else
              {
                $result4=mysqli_query($con,"update parents set pswd='$_POST[pswd]' where email='$_POST[email]'");
              }
            }
            
         if($result4){
           $flag=2;
       }
       else
       {
           $flag=6;
       }
    
        }
    }
    if(isset($_POST['update']))
    {
         
    }
    if(isset($_POST['search']))
    {
        $result=mysqli_query($con,"select * from students where std='$_POST[std]' and rollno='$_POST[roll]' ");
        while($row=mysqli_fetch_array($result))
        {
        $name=$row['name'];
        $roll=$row['rollno'];
        $std=$row['std'];
        $father=$row['father'];
        $mother=$row['mother'];
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
        }
        if(mysqli_num_rows($result)!=0){
           $flag=3;
       }
       else
       {
           $flag=6;
       }
    }
     
    if(isset($_POST['del']))
    {
        $result=mysqli_query($con,"delete from students where std='$_POST[std]' and rollno='$_POST[roll]' ");
         $result=mysqli_query($con,"delete from attendance_records where std='$_POST[std]' and rollno='$_POST[roll]' ");
       if($result){
           $flag=4;
       }
       else
       {
           $flag=6;
       }
    }
       
?>
<?php ?>
<br><br><br><br>
        <div class="container py-3" style="background:white">
            <div class="jumbotron"><h2 align="center"> Student's Registration</h2></div>
            <div class="panel panel-default">
            <?php if($flag==1){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Student added successfully
            </div>    
            <?php }?>
            <?php if($flag==2){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Student updated successfully
            </div>    
            <?php }?>
            <?php if($flag==3){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Student searched successfully
            </div>    
            <?php }?>
            <?php if($flag==4){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Student deleted successfully
            </div>    
            <?php }?>
            <?php if($flag==6){?>
            <div class="alert alert-danger">
                <strong> Error! </strong>Something Went Wrong
            </div>    
            <?php }?>
            
        </div>
       
        <div class="panel panel-body">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                <div class="form-group">
                    <label for="roll">Roll Number</label>
                    <input type="number"name="roll" id="roll"  value="<?php echo $roll;?>"class="form-control" required>
                </div>
               
                 <div class="form-group">
                    <label for="std">Standard</label>
                    <select class="form-control" name="std" id="std"  required>
                        <option value="<?php echo $std;?>"><?php echo $std;?></option>
                        <option value="Tuition">Tuition</option>
                        <option value="1">1</option>
                         <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                       

                    </select>
                   
                </div>
               
                 <div class="form-group">
                    <label for="name">Student Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="father">Father's Name</label>
                    <input type="text"name="father" id="father" value="<?php echo $father;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="mother">Mother's Name</label>
                    <input type="text"name="mother" id="mother" value="<?php echo $mother;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone" id="phone"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email"name="email" id="email"  value="<?php echo $email;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>
                <div class="form-group">
                    
                    <input type="submit"name="add" id="submit" class="btn btn-primary"value="Add" >
                    
                    <input type="submit"name="search" id="search" class="btn btn-primary"value="Search" >
                    <input type="submit"name="del" id="del" class="btn btn-primary"value="delete" >
                </div>
            </form>
        </div>
        </div>
        <?php
             include "footer.php";
               ?>
        
  