<?php

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html='<html><head>
                <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
                </head><body><h1 align="center">Attendance Records of Saket Vidya Mandir</h1>';
$std=$_POST['std'];
$from=$_POST['from'];
$to=$_POST['to'];
$html.='<h3 align="center">'.$std." ".$from." to".$to.'</h3>';

include("db.php");
// if(isset($std,$from,$to))
// {
    $result=mysqli_query($con,"select distinct(Date) from attendance_records where  Date between '$from' and '$to'");
     $html.='
                <table id="customers">
                <tr>
                <th>Rollno</th>
                <th>Name</th>';
    while($row=mysqli_fetch_array($result))
    {
        $date=date("d-M",strtotime($row['Date']));
     $html.='<th>'.$date.'</th>';
                
                
    }
    $html.='</tr>
            ';
            
    $result1=mysqli_query($con,"select * from students where std='$std'  ");
    while($row=mysqli_fetch_array($result1))
    {
        $rollno=$row['rollno'];
        $name=$row['name'];
        $student_id=$std."_".$rollno;
        $html.='<tr>
            <td>'.$rollno.'</td>
        <td>'.$name.'</td>';
       $result2=mysqli_query($con,"select distinct(Date),attendance_status from attendance_records where student_id='$student_id' and Date between '$from' and '$to'");
       while($rw=mysqli_fetch_array($result2))
       {
           $status=$rw['attendance_status'];
           $html.='<td>'.$status.'</td>';
       }
        $html.='</tr>';
    }
        $html.='</table></body></html>';
// }
$dompdf=new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','landscape');
$dompdf->render();
$dompdf->stream('Attendance Records',array("Attachement"=>0));
?>




