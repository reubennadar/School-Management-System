<?php 
include "session.php";
include "header.php";
include "db.php";
$email=$_SESSION['$TEACHER'];
                                $result=mysqli_query($con,"select * from teachers where email='$email'");
                                while($row=mysqli_fetch_array($result))
                                {
                                    $std=$row['std'];
                                }
if($_POST['add'])
{
    $subject=$_POST['subject'];
    $exam=$_POST['exam'];
    $marks=$_POST['marks'];
    
}

?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<br><br><br><br>
<br>
<div class="container">
    
    <div class="jumbotron">
        <h3 align="center">Add Marks</h3>
    </div>
    <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModaladd">Add total</button>

<!-- Modal -->
<div id="myModaladd" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Marks</h4>
      </div>
      <div class="modal-body">
       <form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
            <div class="form-group">
                 <label>Subject</label>
                    <select class="form-control" name="subject" id="subject" onchange="">
                        <?php 
                        $result=mysqli_query($con,"select * from subject where std='$std'");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['name'];?>"><?php echo $row['name'];?> </option>
                        <?php
                        }
                        ?>
                        
                    </select> 
                    
                    
                    <label>Exam:</label>
                    <select name="exam" class="form-control">
                        <option>1st Unit Test</option>
                        <option>2nd Unit Test</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                    <label>Total Marks</label>
                    <input type="number" class="form-control" name="total" oninput="alert(this.value)">
                    
            </div>
            <input type="submit" name="submit" value="add" class="btn btn-success">
       </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
</div>
<?php 
include "footer.php";
?>