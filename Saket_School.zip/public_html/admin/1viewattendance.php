<?php
include("db.php");
$flag=0;
$flag2=0;
include "session.php";

?>
<?php include("header.php");?>
            <script>
          $(document).ready(function(){
              $("#search").click(function(){
$("#myTable tr").each(function () {       
     if ($(this).find("table td:eq(3)").text() == "a") {
         $(this).css("background":"red");    
  }
 
});
});
        </script>
            <style>
/*table {*/
/*  border-collapse: collapse;*/
/*  border-spacing: 0;*/
/*  width: 100%;*/
/*  border: 1px solid #ddd;*/
/*}*/

/*th, td {*/
/*  text-align: left;*/
/*  padding: 8px;*/
/*}*/

/*tr:nth-child(even){background-color: #f2f2f2}*/


/* starts filter search*/
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

/*#myTable {*/
/*  border-collapse: collapse;*/
/*  width: 100%;*/
/*  border: 1px solid #ddd;*/
/*  font-size: 18px;*/
/*}*/

/*#myTable th, #myTable td {*/
/*  text-align: left;*/
/*  padding: 12px;*/
/*}*/

/*#myTable tr {*/
/*  border-bottom: 1px solid #ddd;*/
/*}*/

/*#myTable tr.header, #myTable tr:hover {*/
/*  background-color: #f1f1f1;*/
/*}*/
/*ends filter search*/
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
</style>
    <br><br><br><br>
        <div class="container">
            <div class="jumbotron" style="background:transparent;color:#fff"><h2 align="center">View Student's Attendance</h2></div>
            <div class="panel panel-default">
                 
        
         
         
       
                <div class="panel panel-heading">
                    <!--<div align="right">-->
                    <!-- <button type="button" id="report_button" class="btn  btn-danger btn-sm ">Report</button>-->
                    <!-- </div>-->

  <!-- Button to Open the Modal -->
  
  <button type="button" class="btn btn-info float-left" data-toggle="modal" data-target="#myModalview"><i class="fa fa-eye"></i>&nbsp;View</button>
  
  <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal">
    <i class="fa fa-download"></i>&nbsp;Generate Report
  </button>
    <br>
  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Generate Attendance Report</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <div class="tab">
  <button class="tablinks" onclick="reportCategory(event, 'Date-Wise')">Date-Wise</button>
  <button class="tablinks" onclick="reportCategory(event, 'Monthly')">Monthly</button>
  <button class="tablinks" onclick="reportCategory(event, 'Student-Wise')">Student-Wise</button>
</div>

<div id="Date-Wise" class="tabcontent">
  <h3>Date-Wise</h3>
   <form action="report2.php" method="post">
              <div class="form-group">
                  <label>Std</label>
                    <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>    
              <label>From:</label>
              <input type="date" name="from"class="form-control">
              <label>To:</label>
              <input type="date" name="to" class="form-control">
              <br>
              <input type="submit" value="generate" class="btn btn-success">
              </div>
          </form>
</div>

<div id="Monthly" class="tabcontent">
  <h3>Monthly</h3>
  <form action="monthlyreport.php" method="post">
              <div class="form-group">
                   <label>Std</label>
                    <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>    
                  <label>Month</label>
                    <select class="form-control" name="month" required>
                       <option value="1">Jan</option>
                       <option value="2">Feb</option>
                       <option value="3">Mar</option>
                       <option value="4">April</option>
                       <option value="5">May</option>
                       <option value="6">June</option>
                       <option value="7">July</option>
                        <option value="8">Aug</option>
                        <option value="9">Sep</option>
                        <option value="10">Oct</option>
                         <option value="11">Nov</option>
                          <option value="12">Dec</option>

                    </select>    
              
              </div>
              <input type="submit" value="generate" class="btn btn-success">
              
          </form>
</div>

<div id="Student-Wise" class="tabcontent">
  <h3>Student-Wise</h3>
  <form action="studattreport.php" method="post">
              <div class="form-group">
                  <label>Std</label>
                    <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>   
                    <label>Rollno</label>
                    <input type="number" class="form-control" name="rollno">
              <label>From:</label>
              <input type="date" name="from"class="form-control">
              <label>To:</label>
              <input type="date" name="to" class="form-control">
              <br>
              <input type="submit" value="generate" class="btn btn-success">
              </div>
          </form>
</div>
          
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
  
  

  <!-- Modal -->
  
<div class="modal" id="myModalview">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Show Attendance</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="form-group">
              <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        Std:
                       <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>    
                    From: <input type="date" id="startdate" name="startdate" class="form-control">
                    To: <input type="date" id="enddate" name="enddate" class="form-control">
                        
                        <button  value="submit" id="search"name="submit"class="btn btn-info center-block">search</button>
                    </form>
          </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

                     
                    <?php
                    if($flag){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  inserted successfully
                    </div>
                    <?php
                    }
                    ?>
                    <?php
                    if($flag2){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  Updated successfully
                    </div>
                    <?php
                    }
                    ?>
                     <?php 
                     //echo date("Y-m-d");
                     ?>
                    
                    
                    <?php if(isset($_POST['submit'])){
                    $result1=mysqli_query($con,"select distinct(Date) from attendance_records where  Date between '$_POST[startdate]' and '$_POST[enddate]' order by Date desc");

                    }?><br>
                        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
                                    <div class="panel panel-body" style="overflow-x:auto;">
                        <table class="table table-striped" style="background:#fff" id="myTable">
                            <tr>
                            <th>#Serial no</th>
                            <th>Student Name</th>
                            <th> Roll No</th>
                            <?php while($row=mysqli_fetch_array($result1)){?>
                            <th><?php echo $row['Date']?></th>
                            <?php }?>
                            </tr>
                            <?php
                              //if(isset($_POST['info']))  
                              //{
                              
                                $counter=0;
                                $std=$_POST['std'];
                                #echo $std;
                                
                                $date=$_POST['cdate'];
                                
                                // echo $date;
                                
                                //echo $count."is the count available";
                                $result=mysqli_query($con,"select * from students where std='$std' ");
                                while($row=mysqli_fetch_array($result))
                                {
                                
                                    
                            ?>
                            <tr>
                            <td><?php echo $counter+1?></td>
                            <?php 
                                $n=array($row['name']);
                                $m=array_combine($m,$n);
                                
                                ?>
                            
                            <td><?php $name=$row['name']; echo $name;?></td>
                            <td><?php $rollno=$row['rollno']; echo $rollno;?></td>
                            
                              
                            <?php
                                $counter++;
                                
                             
                            ?>
                            <?php 
                                    $student_id=$std."_".$rollno;
                                   $result2=mysqli_query($con,"select distinct(Date),attendance_status from attendance_records where student_id='$student_id' and Date between '$_POST[startdate]' and '$_POST[enddate]' order by Date desc");
                                    #$result2=mysqli_query($con,"select distinct(Date), attendance_status from attendance_records full outer join on attendance_records.std=attendance.std and attendance_records.rollno=attendance.rollno order by attendance_records.Date ");
                                 while($row=mysqli_fetch_array($result2)){
                                    //  echo "inside result1";
                                     //echo $rollno;
                                    // echo $_POST['std'];
                                     
                                     if($row["attendance_status"] == 'P')
   {
    
  
                                 
                            ?>
                            <td ><span class="badge" style="background-color:green;color:white"><?php echo $row['attendance_status']
                            ?></span></td>
                            <?php 
   }
   if($row["attendance_status"] == 'A')
   {
   ?>
  
                            <td><label class="badge" style="background-color:red;color:white""><?php echo $row['attendance_status']
                            ?></label>
                            </td>
                            <?php } }}?>

                            </tr>
                        </table>
    
                </div>

                </div>
                
                            
                
            </div>
        </div>
       
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script>
        

function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
function reportCategory(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>

   <?php include "footer.php";?>