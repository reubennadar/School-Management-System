<!DOCTYPE html>
<html lang="en">
  <head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
 <!-- ICON NEEDS FONT AWESOME FOR CHEVRON UP ICON -->
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
	<title>Saket Vidya Mandir</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="img/saket-logo.png"/>
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
<style>
* {
  box-sizing: border-box;
}
a{
    color:white;
}

 #loader{
     position:fixed;
     width:100%;
     height:100vh;
     background:#fff url('img/Dual Ball-1s-200px.gif')
     no-repeat center;
     z-index:999999;
     
 }
.navbar {
    transition: all 0.4s;
     /*border-top-left-radius:30px;*/
border-bottom-left-radius:30px; 
/*border-top-right-radius:30px;*/
border-bottom-right-radius:30px; 
}

.navbar .nav-link {
    color: #fff;
}

.navbar .nav-link:hover,
.navbar .nav-link:focus {
    color: #fff;
    text-decoration: none;
}

.navbar .navbar-brand {
    color: #fff;
}


/* Change navbar styling on scroll */
.navbar.active {
    /*background: #fff;*/
    /*background:#28166d;*/
     background-color:#291670;
    background-image: linear-gradient(135deg,#291670 0%,#ea281c 100%);
    box-shadow: 1px 2px 10px rgba(0, 0, 0, 0.1);
}

.navbar.active .nav-link {
    /*color: #555;*/
    color:#fff;
}

.navbar.active .nav-link:hover,
.navbar.active .nav-link:focus {
    /*color: #555;*/
    color:#fff;
    text-decoration: none;
}

.navbar.active .navbar-brand {
    /*color: #555;*/
    color:#fff;
}
.donotshow{
    display:none;
}
#aboutus{
     /*background-color:#291670;*/
    /*background-image: linear-gradient(135deg,#ea281c 100%,#291670 0%);*/
    color:#fff;
    border-top-left-radius:30px;
border-bottom-left-radius:30px; 
border-top-right-radius:30px;
border-bottom-right-radius:30px; 
}
.card,.card-img-top{
     color:#fff;
    border-top-left-radius:30px;
border-bottom-left-radius:30px; 
border-top-right-radius:30px;
border-bottom-right-radius:30px;
    background-image: linear-gradient(135deg,#ea281c 0%,#291670 100%);
     margin: 0 auto; /* Added */
        float: none; /* Added */
        margin-bottom: 10px; /* Added */


}
#row{
     background-color:#291670;
    background-image: linear-gradient(135deg,#291670 0%,#ea281c 100%);
    color:#fff;
    border-top-left-radius:30px;
border-bottom-left-radius:30px; 
border-top-right-radius:30px;
border-bottom-right-radius:30px; 
}
/* Change navbar styling on small viewports */
@media (max-width: 991.98px) {
    .navbar {
        /*background: #fff;*/
        /*background:#28166d;*/
         background-color:#291670;
    background-image: linear-gradient(135deg,#291670 0%,#ea281c 100%);
    /*border-top-left-radius:30px;*/
/*border-bottom-left-radius:30px; */
/*border-top-right-radius:30px;*/
/*border-bottom-right-radius:30px; */
    }

    .navbar .navbar-brand, .navbar .nav-link {
        /*color: #555;*/
        
        color:#fff;
    }
    .navbar-brand{
        font-size:15px;
    }
    .donotshow{
        display:block;
    }
   
   
}


/*
*
* ==========================================
* FOR DEMO PURPOSES
* ==========================================
*
*/
.text-small {
    font-size: 0.9rem !important;
}

#footer{
     background-image: linear-gradient(135deg,#291670 0%,#ea281c 100%);
    border-top-left-radius:30px;
    color:#fff;
/*border-bottom-left-radius:30px; */
border-top-right-radius:30px;
/*border-bottom-right-radius:30px; */
}
body {
    min-height: 110vh;
    /*background:url("https://cdn.pixabay.com/photo/2014/04/20/00/27/overlay-328226_960_720.jpg");*/
     /*background-color:#9b84f0;*/
    background-image: linear-gradient(90deg,#f09892 0%,#9b84f0 100%);

}
/* Make the image fully responsive */
  .carousel-inner img {
    width: 100%;
    height: 100%;
/*     border-top-left-radius:30px;*/
/*border-bottom-left-radius:30px; */
/*border-top-right-radius:30px;*/
/*border-bottom-right-radius:30px; */
  }
  .carousel-caption{
      top: 50%;
        transform: translateY(-50%);
        bottom: initial;

  }
  .carousel-item{
        -webkit-transform-style: preserve-3d;
        -moz-transform-style: preserve-3d;
        transform-style: preserve-3d;
  }
  
}

/*TEstimonial or Ex students*/

.col-center {
	margin: 0 auto;
	float: none !important;
}
#myCarousel {
	margin: 50px auto;
	padding: 0 70px;
}
#myCarousel .item {
	color: #fff;
	font-size: 14px;
    text-align: center;
	overflow: hidden;
    min-height: 290px;
}
#myCarousel .item .img-box {
	width: 135px;
	height: 135px;
	margin: 0 auto;
	padding: 5px;
	border: 1px solid #ddd;
	border-radius: 50%;
}
#myCarousel .img-box img {
	width: 100%;
	height: 100%;
	display: block;
	border-radius: 50%;
}
#myCarousel .testimonial {
	padding: 30px 0 10px;
}
#myCarousel .overview {	
	font-style: italic;
}
#myCarousel .overview b {
	text-transform: uppercase;
	color: #fff;
}
#myCarousel .carousel-control {
	width: 40px;
    height: 40px;
    margin-top: -20px;
    top: 50%;
	background: none;
}
.carousel-control i {
    font-size: 68px;
	line-height: 42px;
    position: absolute;
    display: inline-block;
	color: rgba(0, 0, 0, 0.8);
    text-shadow: 0 3px 3px #e6e6e6, 0 0 0 #000;
}
#myCarousel .carousel-indicators {
	bottom: -40px;
}

.card-block .btn-outline-primary {
  width: 100%;
  border-top-left-radius: 0;
  border-top-right-radius: 0;
  bottom: 0;
  left: 0;
  position: absolute;
}



/* Flip Cards CSS */
.card-container {
  perspective: 700px;
}
.card-flip {
  position: relative;
  width: 100%;
  transform-style: preserve-3d;
  height: auto;
  transition: all 0.5s ease-out;
  background: white;
  border: none;
}

.card-flip div {
  backface-visibility: hidden;
  transform-style: preserve-3d;
  height: 100%;
  width: 100%;
  border: none;
}

.card-flip .front {
  position: relative;
  z-index: 1;
}

.card-flip .back {
    color:#291670;
  position: relative;
  z-index: 0;
  transform: rotateY(-180deg);
}

.card-container:hover .card-flip {
  transform: rotateY(180deg);
}
#fronttitle{
    color:#291670;
}
#back2Top {
    width: 40px;
    line-height: 40px;
    overflow: hidden;
    z-index: 999;
    display: none;
    cursor: pointer;
    -moz-transform: rotate(270deg);
    -webkit-transform: rotate(270deg);
    -o-transform: rotate(270deg);
    -ms-transform: rotate(270deg);
    transform: rotate(270deg);
    position: fixed;
    bottom: 50px;
    right: 0px;
    background-color: #291670;
    color: #fff;
    text-align: center;
    font-size: 30px;
    text-decoration: none;
    border-radius: 10px;
}
#back2Top:hover {
    background-color: #fff;
    color: #291670;
}
#phone{
    width: 40px;
    line-height: 40px;
    overflow: hidden;
    z-index: 999;
    /*display: none;*/
    /*cursor: pointer;*/
    
    position: fixed;
    bottom: 100px;
    right: 0px;
    background-color: #4CAF50;
    color: #fff;
    text-align: center;
    font-size: 30px;
    text-decoration: none;
    border-radius: 10px;
    border-color:#fff;
}
#email{
    width: 40px;
    line-height: 40px;
    overflow: hidden;
    z-index: 999;
    /*display: none;*/
    cursor: pointer;
    
    position: fixed;
    bottom: 150px;
    right: 0px;
    background-color: #fff;
    color: red;
    text-align: center;
    font-size: 30px;
    text-decoration: none;
    border-radius: 10px;
    border-color:#fff;
}


</style>
  <script>
      $(function () {
    $(window).on('scroll', function () {
        if ( $(window).scrollTop() > 10 ) {
            $('.navbar').addClass('active');
        } else {
            $('.navbar').removeClass('active');
        }
    });
});
$(document).ready(function() {
  var front = document.getElementsByClassName("front");
  var back = document.getElementsByClassName("back");

  var highest = 0;
  var absoluteSide = "";

  for (var i = 0; i < front.length; i++) {
    if (front[i].offsetHeight > back[i].offsetHeight) {
      if (front[i].offsetHeight > highest) {
        highest = front[i].offsetHeight;
        absoluteSide = ".front";
      }
    } else if (back[i].offsetHeight > highest) {
      highest = back[i].offsetHeight;
      absoluteSide = ".back";
    }
  }
  $(".front").css("height", highest);
  $(".back").css("height", highest);
  $(absoluteSide).css("position", "absolute");
});
/*Scroll to top when arrow up clicked BEGIN*/
$(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#back2Top').fadeIn();
    } else {
        $('#back2Top').fadeOut();
    }
});
$(document).ready(function() {
    $("#back2Top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});
 $(document).ready(function(){
    //  alert("pow kilo")
  $('[data-toggle="popover"]').popover();   
});
  </script>
 
  </head>
  <body onload="myfunction()">
<div id="loader"></div>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
<span id="email" title="write to us"><i class="fa fa-envelope" aria-hidden="true"></i>
</span>
  <!--<a href="#" id="phone" data-toggle="popover" title="Popover Header" data-content="Some content inside the popover"><i class="fa fa-phone" aria-hidden="true"></i></a>-->

<!--<span id="phone" data-toggle="tooltip" title="8080092305"><i class="fa fa-phone" aria-hidden="true"></i>-->
<!--</span>-->
<a href="#" id="phone"data-toggle="popover"title="Telephone NO:"data-content="8080092305"><li class="fa fa-phone" aria-hidden="true"></li></a>
<a href="#" id="email"data-toggle="popover"title="Write to us at"data-content="saket.school@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>


<header class="header">
   
    
    <nav class="navbar navbar-expand-lg fixed-top py-3">
        
        <div class="container-fluid">
            <a href="#" class="navbar-brand"><img  src="img/saket-logo.png"></a>
            <a href="#" class="navbar-brand text-uppercase font-weight-bold">Saket Vidya Mandir</a>
            <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><i class="fa fa-bars"></i></button>
            
            <div id="navbarSupportedContent" class="collapse navbar-collapse">
                
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"><a href="#" class="nav-link text-uppercase font-weight-bold">Home <span class="sr-only">(current)</span></a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-uppercase font-weight-bold">About</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-uppercase font-weight-bold">Gallery</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-uppercase font-weight-bold">Portfolio</a></li>
                    <li class="nav-item"><a href="#" class="nav-link text-uppercase font-weight-bold">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<div class="donotshow">
    <br><br><br><br><br>
</div>

<div id="demo" class="carousel slide" style="display:block" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/slider.png" alt="Welcome" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>We are known as Yoga Institution</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/slider.png" alt="Welcome" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>Best Extracurriculum</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/slider.png" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>We give the best education to student to learn discipline</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<div class="show">
    <br>
</div>
<div class="container">
    <div class="row" id="row">
    <div class="col-lg-6 col-sm-6 col-md-6" id="aboutus">
       <div class="container text-center">
           <br>
           <h1>About us</h1>
           <p>We are one of the oldest Educational School of Kalyan and we are known as Yoga University.We build our students with bricks of social interaction, cultural activities, confidence, communication skills and last not the least with Love</p>
       </div>
       <br>
    </div>
    <div class="col-lg-6 col-sm-6 col-md-6"id="notices">

<div class="text-center" >
    <br>
    <h1>Notices</h1>
</div>
    <div id="demo2" class="carousel slide" style="display:block" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://thumbs.dreamstime.com/t/green-black-board-school-blackboard-2-3-10164014.jpg" alt="Welcome" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>We are known as Yoga Institution</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="https://thumbs.dreamstime.com/t/green-black-board-school-blackboard-2-3-10164014.jpg" alt="Welcome" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>Best Extracurriculum</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="https://thumbs.dreamstime.com/t/green-black-board-school-blackboard-2-3-10164014.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Welcome to Saket Vidya Mandir</h3>
        <p>We give the best education to student to learn discipline</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo2" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo2" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<br> 
</div>
</div>
 

</div>
<br>
<div class="container">
    <div class="row">
        <div class="col-sm-3 col-md-3 col-lg-3">
    <div class="card">
      <div class="card-body text-center">
       <div class="card-text">
            <p><i class="fa fa-user"></i></p>
      <h3>11+</h3>
      <p>Partners</p>
       </div>
      </div>
    </div>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="card">
      <div class="card-body text-center">
 <div class="card-text">
             <p><i class="fa fa-check"></i></p>
      <h3>55+</h3>
      <p>Projects</p>
       </div>      </div>
    </div>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="card">
      <div class="card-body text-center">
 <div class="card-text">
           <p><i class="fa fa-smile-o"></i></p>
      <h3>100+</h3>
      <p>Happy Clients</p>
       </div>      </div>
    </div>
        </div>
        <div class="col-sm-3 col-md-3 col-lg-3">
            <div class="card">
      <div class="card-body text-center">
 <div class="card-text">
 <p><i class="fa fa-coffee"></i></p>
      <h3>100+</h3>
      <p>Meetings</p>
       </div>      </div>
    </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-md-6 col-xl-6">
            <br>
            <h1 align="center" style="color:#fff;">Hall of Fame</h1>
            <div id="demo3" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="card" align="center" style="width: 14rem;">
    <img class="card-img-top" src="https://www.w3schools.com/howto/img_avatar.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">John Doe</h4>
      <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
      <a href="#" class="btn btn-primary">See Profile</a>
    </div>
  </div>
    </div>
    <div class="carousel-item">
      <div class="card text-center" style="width: 14rem;">
    <img class="card-img-top" src="https://www.w3schools.com/howto/img_avatar.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">John Doe</h4>
      <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
      <a href="#" class="btn btn-primary">See Profile</a>
    </div>
  </div>
    </div>
    <div class="carousel-item">
      <div class="card" align="center" style="width: 14rem;">
    <img class="card-img-top" src="https://www.w3schools.com/howto/img_avatar.png" alt="Card image" style="width:100%">
    <div class="card-body">
      <h4 class="card-title">John Doe</h4>
      <p class="card-text">Some example text some example text. John Doe is an architect and engineer</p>
      <a href="#" class="btn btn-primary">See Profile</a>
    </div>
  </div>
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo3" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo3" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
        </div>
        <div class="col-sm-6 col-md-6 col-xl-6">
            <br>
            <h1 align="center" style="color:#fff">Testimonials</h1>
			<div id="myCarousel" class="carousel slide" data-ride="carousel">
				<!-- Carousel indicators -->
				<ol class="carousel-indicators">
					<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					<li data-target="#myCarousel" data-slide-to="1"></li>
					<li data-target="#myCarousel" data-slide-to="2"></li>
				</ol>   
				<!-- Wrapper for carousel items -->
				<div class="carousel-inner">
					<div class="item carousel-item active">
						<div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar.png" alt=""></div>
						<p class="testimonial">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam eu sem tempor, varius quam at, luctus dui. Mauris magna metus, dapibus nec turpis vel, semper malesuada ante. Idac bibendum scelerisque non non purus. Suspendisse varius nibh non aliquet.</p>
						<p class="overview"><b>Paula Wilson</b>, Media Analyst</p>
					</div>
					<div class="item carousel-item">
						<div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar2.png" alt=""></div>
						<p class="testimonial">Vestibulum quis quam ut magna consequat faucibus. Pellentesque eget nisi a mi suscipit tincidunt. Utmtc tempus dictum risus. Pellentesque viverra sagittis quam at mattis. Suspendisse potenti. Aliquam sit amet gravida nibh, facilisis gravida odio.</p>
						<p class="overview"><b>Antonio Moreno</b>, Web Developer</p>
					</div>
					<div class="item carousel-item">
						<div class="img-box"><img src="https://www.w3schools.com/howto/img_avatar2.png" alt=""></div>
						<p class="testimonial">Phasellus vitae suscipit justo. Mauris pharetra feugiat ante id lacinia. Etiam faucibus mauris id tempor egestas. Duis luctus turpis at accumsan tincidunt. Phasellus risus risus, volutpat vel tellus ac, tincidunt fringilla massa. Etiam hendrerit dolor eget rutrum.</p>
						<p class="overview"><b>Michael Holz</b>, Seo Analyst</p>
					</div>
				</div>
				<!-- Carousel controls -->
				<a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
					<i class="fa fa-angle-left"></i>
				</a>
				<a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
					<i class="fa fa-angle-right"></i>
				</a>
			</div>
        </div>
    </div>
</div>
<div class="container">
    <br>
    <h1 align="center" style="color:#fff">Extracurricular Activities</h1>
    <br>
  <div class="row text-center">
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <!-- To add FontAwesome Icons use Unicode characters and to set size use font-size instead of fa-*x because when calculating the height (see js), the size of the icon is not calculated if using classes -->
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          
          <h4 class="card-title" id="fronttitle">Karate</h4>
          <h6 class="card-subtitle text-muted">
             
          <img src="https://storage.needpix.com/rsynced_images/karate-3615008_1280.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
          </h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
            <br>
          <p>
            
           Every Saturday 8am to 10.30 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          <h4 class="card-title" id="fronttitle">Western Dance</h4>
          <h6 class="card-subtitle text-muted">
          <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Break_Dancer.png" class="img-fluid img-thumbnail"style="width:50%;height:50%"></h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
          <br>
          <p>
            
           Every Saturday 8am to 10.30 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          <h4 class="card-title" id="fronttitle">Classical Dance</h4>
          <h6 class="card-subtitle text-muted">
              <img src="https://clipartstation.com/wp-content/uploads/2017/11/classical-dance-clipart-black-and-white.jpg" class="img-fluid img-thumbnail"style="width:50%;height:50%">
          </h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
          <br>
          <p>
            
           Every Saturday 8am to 10.30 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          <h4 class="card-title" id="fronttitle">Singing</h4>
          <h6 class="card-subtitle text-muted">
              <img src="https://upload.wikimedia.org/wikipedia/commons/4/46/Singer_icon_transparent.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
          </h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
          <br>
          <p>
            
           Every Saturday 8am to 10.30 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          <h4 class="card-title" id="fronttitle">Drawing</h4>
          <h6 class="card-subtitle text-muted">
               <img src="https://cdn3.iconfinder.com/data/icons/miscellaneous-17-solid/128/hobby_creative_artist_easel_painting_drawing_sketch-512.png" class="img-fluid img-thumbnail"style="width:50%;height:50%">
          </h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
          <br>
          <p>
            
           Every Saturday 8am to 10.30 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
    <div class="col-md-4 card-container">
      <div class="card card-flip">
        <div class="front card-block">
          <span class="card-img-top fa" style="font-size: 4em">&#xf118;</span>
          <h4 class="card-title" id="fronttitle">Yoga and Exercise</h4>
          <h6 class="card-subtitle text-muted">
           <img src="https://svgsilh.com/svg_v2/2029429.svg" class="img-fluid img-thumbnail"style="width:50%;height:50%">
          </h6>
          <p class="card-text">Front Text</p>
        </div>
        <div class="back card-block">
           <br>
          <p>
            
           Monday to Friday at 8 am
          </p>
          <a href="#" class="btn btn-outline-danger" style="border-radius:20px">Read More</a>
        </div>
      </div>
    </div>
  </div>
</div>
<br>
<!-- Footer -->
<footer class="page-footer font-small mdb-color lighten-3 pt-4"id="footer">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Content -->
        <h5 class="font-weight-bold text-uppercase mb-4">Footer Content</h5>
        <p>Here you can use rows and columns to organize your footer content.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Fugit amet numquam iure provident voluptate
          esse
          quasi, veritatis totam voluptas nostrum.</p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Links -->
        <h5 class="font-weight-bold text-uppercase mb-4">About</h5>

        <ul class="list-unstyled" style="color:white">
          <li>
            <p>
              <a href="#!">PROJECTS</a>
            </p>
          </li>
          <li>
            <p>
              <a href="#!">ABOUT US</a>
            </p>
          </li>
          <li>
            <p>
              <a href="#!">BLOG</a>
            </p>
          </li>
          <li>
            <p>
              <a href="#!">AWARDS</a>
            </p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="font-weight-bold text-uppercase mb-4">Address</h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <i class="fas fa-home mr-3"></i> New York, NY 10012, US</p>
          </li>
          <li>
            <p>
              <i class="fas fa-envelope mr-3"></i> info@example.com</p>
          </li>
          <li>
            <p>
              <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
          </li>
          <li>
            <p>
              <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 text-center mx-auto my-4"style=" ">

        <!-- Social buttons -->
        <h5 class="font-weight-bold text-uppercase mb-4">Follow Us</h5>

        <!-- Facebook -->
        <a type="" class="btn-floating btn-fb">
          <i class="fab fa-facebook" style="color:blue; font-size:48px;"></i>
        </a><br>
        <!-- Twitter -->
        <a type="" class="btn-floating btn-tw"style="color:blue; font-size:48px">
          <i class="fab fa-twitter"></i>
        </a><br>
        <!-- Google +-->
        <a type="" class="btn-floating btn-gplus"style="color:blue; font-size:48px">
          <i class="fab fa-google-plus-g"></i>
        </a><br>
        <!-- Dribbble -->
        <a type="" class="btn-floating btn-dribbble"style="color:blue; font-size:48px">
          <i class="fab fa-instagram"></i>
        </a><br><br>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="www.saketschool.cf"> SaketSchool.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
<script>
        var preloader=document.getElementById("loader");

    function myfunction(){
        preloader.style.display="none";
    }
</script>
  </body>
  </html>