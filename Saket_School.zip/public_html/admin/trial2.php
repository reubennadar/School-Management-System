<?php
include("db.php");
$flag=0;
$flag2=0;
include("session.php");
if(isset($_POST['submit']))
{
    
    // echo "inside if statement";
    $counter=0;
    $present=0;
    $absent=0;
    foreach($_POST['attendance_status'] as $id=>$attendance_status){
        //echo " inside foreach";
       
       
         $name=$_POST['name'][$id];
         //echo $name;
        $rollno=$_POST['rollno'][$id];
        $date=$_POST['cdate'];
        $std=$_POST['std'];
        $student_id=$std."_".$rollno;
        //echo $std;
        // $div=$_POST['div'];
        if($attendance_status==null)
          {
              $attendance_status='A';
          }
         if($attendance_status=="P")
         {
             $present++;
         }
         else
         {
             $absent++;
         }
         
        $result=mysqli_query($con,"select * from attendance_records where Date='$date' and  student_id='$student_id'");
        if(!mysqli_num_rows($result))
        {
          //  //echo "inside num rows";
          
          
        $result= mysqli_query($con,"insert into attendance_records values('$date','$student_id','$attendance_status')");
        //$my=mysqli_query($con,"insert into attendance_records values('$date','$rollno','$name','$attendance_status')");
        
          
         
           if($result)
        {
            $flag=1;
        }
                
          }
        else
        {
            
            $result=mysqli_query($con,"update attendance_records set attendance_status='$attendance_status' where Date='$date' and student_id='$student_id'");
            
          
              if($result)
        {
            $flag2=1;
        }
        $counter++;
            
        }
    
    }
    //mysqli_query($con,"insert into attendance_records values('01/20/22',12,'Reuben','present')");
}
?>
<?php include "header.php"?>
<style>
    #myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
<script>
    $(document).ready(function(){
        $("#allpresent").click(function(){
            if(this.checked)
            {
                //alert("checked");
                
                if($("input[id=attendance_checkbox]").prop("checked",true))
                {
                    $("input[id=attendance_checkbox]").click();
                    $("input[id=attendance_checkbox]").click();
                }
                else
                {
                    $("input[id=attendance_checkbox]").click();
                }
            }
            else
            {
                $("input[id=attendance_checkbox]").click();
            }
        })
    })
    function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}
</script>
<br><br><br><br>
        <div class="container py-3" style="background:white">
            <div class="jumbotron" style=""><h2 align="center">Add Student's Attendance</h2></div>
            <div class="panel panel-default">
                <div class="panel panel-heading">
                    <h2>
                    
                    
                    </h2>
                    <?php
                    if($flag){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  inserted successfully
                    </div>
                    <?php
                    }
                    ?>
                    <?php
                    if($flag2){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  Updated successfully
                    </div>
                    <?php
                    }
                    ?>
                     <?php 
                     ////echo date("Y-m-d");
                     ?>
                     <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModaladd">+ADD</button>

 
 
   <div class="modal" id="myModaladd">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Attendance</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div class="form-group">
             <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        
                           
                                 <label for="Std">Std</label>
                                
                                    
                <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>                                 
                   
                                
                                                           
                            
                             
                               
                                
                           
                       <br>
                    <button  value="submit" name="info" class="btn btn-info center-block ">search</button>
                                            <!--Division:<input type="text"name="div">--><br>
                        
                    </form>
         </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>                 
                    
                    <br>
                    <br>
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="Post">
                        <div class="form-group row text-center">
                            <b class="col-sm-2"></b>
                                <label for="date" class="col-sm-2 col-form-label">Date</label>
                                <div class="col-sm-3">
                                    
                                    <input type="date" class="form-control" id="date"name="cdate" value="<?php 
                                    if(isset($_POST['cdate'])) 
                                    { echo $_POST['cdate'];}
                                    else { echo date('Y-m-d');}?>">
                                 </div>
                         </div>
                        <br>
                        <div id="sub" class="text-center">
                            <?php if($_POST['submit'])
                            {
                            ?>
                           
                            <span class="badge-success">Present</span>:<?php echo $present;?><br>
                            <span class="badge-danger">Absent</span>:<?php echo $absent;?>
                            <?php
                            }
                            ?>
                        </div>
                        
                                    <div class="panel panel-body">
                                        <div class="float-right">
                                            
                                            <input type="checkbox" class="form-check-input" id="allpresent">All Present
                                        </div>
                    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
                        <table class="table table-striped" id="myTable">
                            <tr>
                            <th>#Serial no</th>
                            <th>Student Name</th>
                            <th> Roll No</th>
                            <th>Attendance Status</th>
                            </tr>
                            <?php
                              //if(isset($_POST['info']))  
                              //{
                                $counter=0;
                                $std=$_POST['std'];
                                // echo $std;
                                //$div=$_POST['div'];
                                //echo $div;
                                $result=mysqli_query($con,"select * from students where std='$std'");
                                while($row=mysqli_fetch_array($result))
                                {
                                    
                            ?>
                            <tr>
                            <td><?php echo $counter+1?></td>
                            <td><?php echo $row['name']?></td>
                            <input type="hidden" value="<?php echo $row['name']?>" name="name[]">
                            <td><?php echo $row['rollno']?></td>
                            <input type="hidden" value="<?php echo $row['rollno']?>" name="rollno[]">
                            <input type="hidden" value="<?php echo $std?>" name="std">
                            
                            <td>
                                <?php 
                       if($_POST['attendance_status'][$counter]=="P")
                       {
                           ?>
                           <input type="hidden" id="attendance_status[<?php echo $counter;?>]"name="attendance_status[<?php echo $counter;?>]" value="P">
                           <?php
                       } 
                       else
                       {
                       ?>
                                <input type="hidden" id="attendance_status[<?php echo $counter;?>]"name="attendance_status[<?php echo $counter;?>]" value="A">
                    <?php } ?>
                                <input type="checkbox" onclick="
                                if(this.checked)
                                {document.getElementById('attendance_status[<?php echo $counter;?>]').value='P';
                               // alert(document.getElementById('attendance_status[<?php echo $counter;?>]').value);
                               }
                                else
                                
                                {document.getElementById('attendance_status[<?php echo $counter;?>]').value='A';
                                //alert(document.getElementById('attendance_status[<?php echo $counter;?>]').value);
                                }
                       document.getElementById('div[<?php echo $counter;?>]').innerHTML=document.getElementById('attendance_status[<?php echo $counter;?>]').value;" 
                       <?php 
                       if($_POST['attendance_status'][$counter]=="P")
                       { echo "checked=checked";
                       } 
                       ?> id="attendance_checkbox"
                           > 
                           
                           
                            <?php  if($_POST['attendance_status'][$counter]=="P")
                       {        
                           
                           ?>
                            <b id="div[<?php echo $counter;?>]" > P</b>

                          
                           <?php
                       } 
                       else
                       {
                       ?>
                                <b id="div[<?php echo $counter;?>]" > A</b>
                   
                             

                           
                            <?php }?>
                            <!--<input type="radio" name="attendance_status[<?php echo $counter;?>]" value="A">Absent-->
                            </td>
                            </tr>   
                            <?php
                                $counter++;
                                }
                             
                            ?>


                        </table>
                        <input type="submit" value="submit" name="submit" class="btn btn-primary">
                   
                </div>
                 </form>

                </div>
                
                            
                
            </div>
            <br>
        </div>

        
   <?php include("footer.php");