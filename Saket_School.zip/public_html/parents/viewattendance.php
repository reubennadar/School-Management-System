<?php
include("db.php");
include "session.php";

if(isset($_POST['logout'])){
    session_destroy();
}
$flag=0;
$flag2=0;
?>
<?php include("header.php");?>
<script> 
            $(document).ready(function() {  
                $("button").click(
                    function(){   
                        var month=this.value;
                        var year=
                        $('#body').load('viewattendance3.php',{month: month});          
                    }   
                ); //end click       
            }); //end ready 
</script>
<br>
<br>
<br>
<br>
<br>
        <div class="container py-3 "style="background:white">
            <div class="jumbotron">
                            <div class="well text-center"><h2><?php echo $name; ?>'s Attendance</h2></div>

            </div>
            <div class="panel panel-default">
                <div class="panel panel-heading">
                    <h2>
                    
                    
                    </h2>
                    
                     <?php 
                    	$result1=mysqli_query($con, "select attendance_status from attendance_records where student_id='$student_id' and attendance_status='P'");
                    	$presenttotal=mysqli_num_rows($result1);
                    		$result1=mysqli_query($con, "select attendance_status from attendance_records where student_id='$student_id'");
                    		$total=mysqli_num_rows($result1);
                    		$overalldiv=$presenttotal/$total;
                    		$overall=round($overalldiv*100);
                     ?>
                  
                    
                        
                        <center><b><?php echo "Std: "?></b><?php echo $std;?></center>
                        <center><b><?php echo "Rollno: "?></b><?php echo $rollno;?></center>
                        <center><b><?php echo "Name: "?></b><?php echo $name;?></center>
                        <center><b><?php echo "Over all Attendance: "?></b><?php echo $overall.'%';?></center>
                                    <div class="panel panel-body table-responsive">
                        <table class="table  table-striped">
                            <tr>
                            <th>#Serial no</th>
                            
                            <th>Month</th>
                            <th>Present/Total</th>
							
							<th>Percentage</th>
							<th>Action</th>
                            </tr>
                            <?php
                            
                                $counter=0;
                                
                                $result=mysqli_query($con,"select distinct Monthname(Date) as 'Month',Year(Date) as 'Year' from  attendance_records where student_id like '$std_%' order by 'Month' and 'Year' ");
                                while($row=mysqli_fetch_array($result))
                                {
								$month=$row['Month'];
								$year=$row['Year'];
                                    
                            ?>
                            <tr>
                            <td><?php echo $counter+1?></td>
                            
                            <td><?php echo $month." ".$year?></td>
							<?php
							$result1=mysqli_query($con, "select attendance_status from attendance_records where student_id='$student_id' and attendance_status='P' and monthname(Date)='$month' and Year(Date)='$year'");
						    $presentcount=mysqli_num_rows($result1);
						
							$result2=mysqli_query($con, "select attendance_status from attendance_records where student_id='$student_id' and monthname(Date)='$month' and Year(Date)='$year'");
						    $totalcount=mysqli_num_rows($result2);
							?>
							<td><?php echo $presentcount.'/'.$totalcount;?></td>
					        <?php
					        $div=$presentcount/$totalcount;
					        $percentage=round($div*100);
					        
					        ?>
					        <td><?php echo $percentage.'%';?></td>
					         <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#mymodal" id="button" value="<?php echo $month.' '.$year.' '.$student_id;?>">View</button >
					         
 
</td>
					        
					          
                            </tr>   
                            
                            <?php
                                $counter++;
                                }
                             
                            ?>
                           
                       

                        </table>
  
                </div>

                </div>
                
                            
                
            </div>
        </div>
      <br>
        <!-- The Modal -->
  <div class="modal fade" id="mymodal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title"></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body" id="body">
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>
 <?php include("footer.php");?>