<?php
try{
 $con=new PDO('mysql:host=localhost;dbname=id11184380_attendance;charset=utf8','id11184380_admin','admin');
// $con=mysqli_connect("localhost","id11184380_admin","admin","id11184380_attendance");

}
catch(PDOException $e){
    echo $e->getMessage();
}
?>