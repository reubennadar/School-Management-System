<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <script src='https://kit.fontawesome.com/a076d05399.js'></script>
      <!-- ICON NEEDS FONT AWESOME FOR CHEVRON UP ICON -->
      <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
      <title>Saket Vidya Mandir</title>
      <!-- Favicon -->
      <link rel="shortcut icon" type="image/icon" href="img/saket-logo.png"/>
      <link rel="stylesheet" href="style.css">
      <script src="script.js"></script>
      <!-- Lightbox usage markup -->
      <link href="https://fonts.googleapis.com/css?family=Raleway:200,100,400" rel="stylesheet" type="text/css" />
   </head>
   <body onload="loader()">
      <div id="loader"></div>
      <a id="back2Top" title="Back to top" href="#">&#10148;</a>
      <span id="email" title="write to us"><i class="fa fa-envelope" aria-hidden="true"></i>
      </span>
      
      <a href="tel:8080092305" id="phone"data-toggle="popover"title="Telephone NO:"data-content="8080092305">
         <li class="fa fa-phone" aria-hidden="true"></li>
      </a>
      <a href="mailto:saketschool@gmail.com" id="email"data-toggle="popover"title="Write to us at"data-content="saket.school@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
      <header class="header">
         <nav class="navbar navbar-expand-lg fixed-top py-3">
            <div class="container-fluid">
               <a href="home" class="navbar-brand"><img  src="img/saket-logo.png"></a>
               <a href="home" class="navbar-brand text-uppercase font-weight-bold">Saket Vidya Mandir</a>
               <button type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><i class="fa fa-bars"></i></button>
               <div id="navbarSupportedContent" class="collapse navbar-collapse">
                  <ul class="navbar-nav ml-auto">
                     <li class="nav-item active"><a href="home" class="nav-link text-uppercase font-weight-bold"><span class="fa fa-home"></span>&nbsp;Home <span class="sr-only">(current)</span></a></li>
                     <!--<li class="nav-item"><a href="#" class="nav-link text-uppercase font-weight-bold">About</a></li>-->
                     <li class="nav-item"><a href="gallery" class="nav-link text-uppercase font-weight-bold"><span  class="fa fa-image"></span>&nbsp;Gallery</a></li>
                    
                     <li class="nav-item"><a href="contact" class="nav-link text-uppercase font-weight-bold"><span  class="fa fa-phone"></span>&nbsp;Contact</a></li>
                      <div class="dropdown">
    <li  class="nav-item dropdown-toggle nav-link text-uppercase font-weight-bold" data-toggle="dropdown">
      <i class="fas fa-sign-in-alt"></i>&nbsp;Login


    </li>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="parents/login"><i class="fas fa-sign-in-alt"></i>&nbsp;Parent </a>
      <a class="dropdown-item" href="teachers/login"><i class="fas fa-sign-in-alt"></i>&nbsp;Teacher </a>
      <a class="dropdown-item" href="admin/login"><i class="fas fa-sign-in-alt"></i>&nbsp;Admin </a>
    </div>
  </div>
                  </ul>
               </div>
            </div>
         </nav>
      </header>
     