<?php
include("session.php");
include("header.php");
include("db.php");
if($_POST['add'])
{
    $std=$_POST['std'];
    $no=$_POST['no'];
    $flag=0;
    $output="";
    $i=0;
    $me="";
    $array=array();
    while($no)
    {   $i++;
        $sub="sub".$i;
        
        $array[$i]=$_POST['Subject'.$i];
        $output.=$array[$i];
        $subject=$array[$i];
        $subject_id=$std."_".$array[$i];
        $result=mysqli_query($con,"insert into subject(std,subject_id,name) values('$std','$subject_id','$subject')");
        $no--;
        if($result)
        {
            $flag++;
        }
       
    }
    
}
?>
<br><br><br><br><br>
<div class="container py-3" style="background:white" align="center">
    <div class="jumbotron">
      <h2 align="center">Add Subjects</h2>
   </div>
   <?php if($flag!=0){?>
   <div class="alert alert-success">
       Success!! Subjects added successfully
   </div>
   <?php }?>
   <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModaladd">+Add Subjects</button>

<!-- Modal -->
<!--<div id="myModaladd" class="modal fade" role="dialog">-->
<!--  <div class="modal-dialog">-->

    <!-- Modal content-->
<!--    <div class="modal-content">-->
<!--      <div class="modal-header">-->
<!--        <button type="button" class="close" data-dismiss="modal">&times;</button>-->
<!--        <h4 class="modal-title">Add Subjects</h4>-->
<!--      </div>-->
<!--      <div class="modal-body">-->
       
<!--      </div>-->
<!--      <div class="modal-footer">-->
<!--        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
<!--      </div>-->
<!--    </div>-->

<!--  </div>-->
<!--</div>-->
<div class="modal" id="myModaladd">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Subjects</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
 <div class="form-group" >
            <form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
                <label>Std</label>
                    <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>

                    </select>   
                    <label>No of Subjects</label>
                    <input type="number" name="no" class="form-control" id="no" onkeyup="myfunction()">
                    <div id="form-group" class="form-group">
                        
                    </div>
                    <input type="submit" value="add" class="btn btn-success" name="add">
                    
                    
            </form>
        </div>
        </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<div class="row py-3" align="center">
<?php 
$result=mysqli_query($con,"select * from std");
$count=mysqli_num_rows($result);
while($row=mysqli_fetch_array($result))
{
    $std=$row['std'];
    $result1=mysqli_query($con,"select * from subject where subject_id like '$std%'");
    if($result1)
    {
        ?> 
        
        <div class="table-responsive col-sm-4">
                <h4 align="center"> Std <?php echo $std?></h4>
                <table class="table table-striped" >
                                
                    <tr >
                        <th>Subject Name</th>
                        
                    </tr>
        <?php
        //$me.="inside";
        while($row1=mysqli_fetch_array($result1))
        {
            $subject_id=$row1['subject_id'];
            $name=$row1['name'];
            ?>
            
                    <tr>
                        <td><?php echo $name;?></td>
                    </tr>
            
            <?php
        }
        ?>
                        </table>

        </div>
        <?php
    }
}
?>
</div>
</div>
<script>
                    function myfunction()
                    {
                        var no=document.getElementById('no').value;
                        var div=document.getElementById('form-group');
                        div.innerHTML='';
                        var n=parseInt(no);
                        var i;
                        var name;
                        for(i=1;i<=no;i++)
                        {
                            name="Subject"+i;
                            div.innerHTML+="<label>"+name+"</label><input type='text' name='"+name+"' class='form-control' placeholder='Please enter the subject name'>";
                        }
                    }
                    </script>
<?php
echo $me;
include "footer.php";
?>