<?php
include "db.php";
include "session.php";

include "header.php";

                   
                    ?>
<br><br><br><br><br>
<div class="container py-3" style="background:white">
    <div class="jumbotron">
        <h1 align="center">Marks</h1>

    </div>
    <div class="row">
            
            <?php
            
        $result=mysqli_query($con, "select distinct(exam) from marks  order by exam" );
        // echo $student_id;
        if(mysqli_num_rows($result)!=0)
        {
             while($rows=mysqli_fetch_array($result))
                {
            ?>
            <div class="col-sm-3 table-responsive">
            <h1 align="center">
                <?php
                    $exam=$rows['exam'];
                    echo $rows['exam'];
                
                ?>
            </h1>
            <table class="table table-striped">
                <tr>
                    <!--<th>Exam</th>-->
                    <!--<th>Rollno</th>-->
                    <!--<th>Name</th>-->
                    <th>Subject</th>
                    <th>Marks</th>
                    <th>Out of</th>
                </tr>
            <?php
            $result1=mysqli_query($con, "select * from marks where student_id='$student_id' and exam='$exam'");
            while($row=mysqli_fetch_array($result1))
            {
                
                ?>
                <tr>
                    <!--<td><?php //echo $row['exam'];?></td>-->
                    <!--<td><?php //echo $rollno?></td>-->
                    <!--<td><?php //echo $name;?></td>-->
                    <td><?php $result2=mysqli_query($con, "select * from subject where subject_id='$row[subject_id]'");
                    while($row1=mysqli_fetch_array($result2)){
                    echo $row1['name'];}?></td>
                    <td><?php echo $row['marks'];?></td>
                    <td><?php echo $row['outof'];?></td>
                    
                        
                </tr>
               
                
                
                <?php
            }
            ?>
             </table>
             </div>
             <?php
        }
    
        }
       
        ?>
        </div>
</div>
<br>
<?php include "footer.php"?>
