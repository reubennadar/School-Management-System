<?php 
include "session.php";
include "header.php";
include "db.php";
if(isset($_POST['submit']))
{
    $std2=$_POST['std'];
    $exam=$_POST['exam'];
    $total=$_POST['total'];
    $subject=$_POST['subject'];
    $marks=$_POST['total'];
}
if(isset($_POST['add']))
{
    $c=0;$b=0;
    $me="";
    foreach($_POST['marks'] as $id=>$marks)
    {
        $student_id=$_POST['student_id'][$id];
        $std=$_POST['std'];
        $subject=$_POST['subject'];
        $exam=$_POST['exam'];
        $outof=$_POST['outof'];
        $subject_id=$std."_".$subject;
        $me.=$student_id. " ,". $subject_id.", ".$exam.", ".$marks.", ".$outof."<br>";
        $result=mysqli_query($con,"insert into marks (exam,student_id,subject_id,marks,outof) values('$exam','$student_id','$subject_id','$marks','$outof')");
        if($result)
        {
            $c++;
        }
        else
        {
            $b++;
        }
    }
    $s="sucess";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<br><br><br><br>
<br>
<div class="container py-3" style="background:white">
    
    <div class="jumbotron">
        <h3 align="center">Add Marks</h3>
    </div>
    <!-- Trigger the modal with a button -->
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModaladd">Add total</button>

<!-- Modal -->
<div id="myModaladd" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
       
        <h4 class="modal-title">Marks</h4>
         <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
       <form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
            <div class="form-group">
                 <label>Std</label>
                    <select class="form-control" name="std" id="std" onchange="">
                        <option>Select</option>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>
                        
                    </select> 
                    <div class="" id="sub">
                     
                    </div>
                    
                    <label>Exam:</label>
                    <select name="exam" class="form-control">
                        <option>1st Unit Test</option>
                        <option>2nd Unit Test</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                    <label>Total Marks</label>
                    <input type="number" class="form-control" name="total" oninput="">
                    
            </div>
            <input type="submit" name="submit" value="add" class="btn btn-success">
       </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php
if($c!=0)
{
?>
<div class="alert alert-success">
    Success! Marks have been added 
</div>

<?php
}
?>
<?php
if(b!=0)
{
?>
<div class="alert alert-danger">
    Error! Something went wrong
</div>

<?php
}
?>
<div class="text-center">
                           


    <?php echo "<b>STD</b>: ".$std2."<br>";
            echo "<b>Exam</b>: ".$exam."<br>";
            echo "<b>Subject</b>:".$subject."<br>";
            echo "<b>Marks</b>: ".$marks."<br>";
    ?>
                            
</div>

<form name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" >
<div class="table-responsive">
<table class="table table-striped">
    <tr>
        <th>Rollno</th>
        <th>Name</th>
        <th>Marks Obtained in <?php echo $subject;?></th>
        <th> Out of Marks</th>
    </tr>
<input type="hidden" name="std" value="<?php echo $std2;?>">
                        <input type="hidden" name="exam" value="<?php echo $exam;?>">
                        <input type="hidden" name="subject" value="<?php echo $subject;?>">
                        
                        <input type="hidden" name="outof" value="<?php echo $marks;?>">


    <?php
    $result=mysqli_query($con,"select * from students where std='$std2'");
    $i=0;
    while($row=mysqli_fetch_array($result))
    {
        
    ?>
    <tr>
        <td><?php echo $row['rollno'];?>
        <input type="hidden" name="student_id[]" value="<?php echo $row['student_id'];?>"></td>
        <td><?php echo $row['name'];?></td>
        <td><div class=""><input type="number" class="form-control" name="marks[<?php echo $i;?>] " placeholder="marks[<?php echo $i;?>] "></div></td>
        <td><?php echo "<h4>/".$marks."</h4>"?></td>
    </tr>
    <?php
    $i++;
    }
    
    ?>
    
</table></div>
<div class="text-center">
    <input type="submit" value="Add" class="btn btn-success" name="add">

</div>
</form>
</div>
<script>
  $(document).ready(function(){
 $("#std").change(function(){
  //alert('The text has been changed.');
   val=$('#std').val();
   
   $('#sub').load("marks2.php", {
       std: val
   });
   
 
  
});
});
</script>
<br>
<?php 
// echo $s;
// echo $me;

include "footer.php";
?>