function loader(){
             var preloader=document.getElementById("loader");

         preloader.style.display="none";
         }
 $(function () {
         $(window).on('scroll', function () {
           if ( $(window).scrollTop() > 10 ) {
               $('.navbar').addClass('active');
           } else {
               $('.navbar').removeClass('active');
           }
         });
         });
         $(document).ready(function() {
         var front = document.getElementsByClassName("front");
         var back = document.getElementsByClassName("back");
         
         var highest = 0;
         var absoluteSide = "";
         
         for (var i = 0; i < front.length; i++) {
         if (front[i].offsetHeight > back[i].offsetHeight) {
         if (front[i].offsetHeight > highest) {
           highest = front[i].offsetHeight;
           absoluteSide = ".front";
         }
         } else if (back[i].offsetHeight > highest) {
         highest = back[i].offsetHeight;
         absoluteSide = ".back";
         }
         }
         $(".front").css("height", highest);
         $(".back").css("height", highest);
         $(absoluteSide).css("position", "absolute");
         });
         /*Scroll to top when arrow up clicked BEGIN*/
         $(window).scroll(function() {
         var height = $(window).scrollTop();
         if (height > 100) {
           $('#back2Top').fadeIn();
         } else {
           $('#back2Top').fadeOut();
         }
         });
         $(document).ready(function() {
         $("#back2Top").click(function(event) {
           event.preventDefault();
           $("html, body").animate({ scrollTop: 0 }, "slow");
           return false;
         });
         
         });
         $(document).ready(function(){
         //  alert("pow kilo")
         $('[data-toggle="popover"]').popover();   
         });
         
         