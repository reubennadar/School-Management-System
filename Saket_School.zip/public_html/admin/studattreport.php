<?php
include("db.php");

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html='<html><head>
                <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
                </head><body><h1 align="center">Attendance Records of Saket Vidya Mandir</h1>';
$std=$_POST['std'];
$rollno=$_POST['rollno'];
$student_id=$std.'_'.$rollno;
$from=$_POST['from'];
$to=$_POST['to'];
$result=mysqli_query($con,"select * from students where student_id='$student_id'");
while($row=mysqli_fetch_array($result))
{
    $name=$row['name'];
    $father=$row['father'];
    $mother=$row['mother'];
    
}
$html.='<h3 align="center">'."Std: ".$std." Rollno ".$rollno." Name: ".$name." From:".$from." to: ".$to.'</h3>';
$result2=mysqli_query($con,"select distinct(Date),attendance_status from attendance_records where student_id='$student_id' and Date between '$from' and '$to'");
$html.='<table class="table">
<tr>
<th>Date</th>
<th>Attendance Status</th>
</tr>';
while($row=mysqli_fetch_array($result2))
{
    $html.='<tr>
            <td>'.$row["Date"].'</td>
            <td>'.$row["attendance_status"].'</td>
            </tr>';
}
$html.='</table>';

    $html.='</body></html>';
// }
$dompdf=new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','Portrait');
$dompdf->render();
$dompdf->stream('Attendance Records',array("Attachement"=>0));
?>




