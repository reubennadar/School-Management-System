<?php include("db.php");
   include("session.php");
   include("header.php");
   
   
   $target_dir = "uploads/";
   $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
   $uploadOk = 1;
   $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   // Check if image file is a actual image or fake image
   if(isset($_POST['del']))
   {
       $student_id=$_POST['student_id'];
       $result=mysqli_query($con,"delete from students where student_id='$student_id' ");
       If($result)
       {
         $result2=mysqli_query($con,"delete from attendance_records where student_id='$student_id' ");
       }
       if($result2){
           $flag=5;
       }
       else
       {
           $flag=3;
       }
   }
   if(isset($_POST['update']))
   {
       
       
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
   $achievers_id=$_POST['achievers_id'];
  if($_FILES["fileToUpload"][name]==null)
  {
      $update="inside no wala";
      $student_id=$_POST['student_id'];
   $result=mysqli_query($con,"update students set  name='$_POST[name]',father='$_POST[father]',mother='$_POST[mother]',phone='$_POST[phone1]',email='$_POST[email1]',pswd='$_POST[pswd]' where student_id='$student_id' ");
   if($result)
   {
       $flag=2;
   }
          
    
  }
  else
  {
   
   $update="inside else wala ";
   // echo $name;
   // echo $date;
   // echo $image;
   // echo $title;
   
   // echo $date;
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           
   
   $title=$_POST['title'];
   $description=$_POST['description'];
      $student_id=$_POST['student_id'];
     $result=mysqli_query($con,"update students set name='$_POST[name]',phone='$_POST[phone1]',email='$_POST[email1]',pswd='$_POST[pswd]',image='$filename',father='$_POST[father]',mother='$_POST[mother]' where student_id='$student_id'");
            if($result)
            {
                $flag=2;
            }
            else
       {
           $flag=6;
       }
    
   }
   
   }
   
             
            
            
        
       
    
        }
   if($flag==2)
   {
       echo "data updated successfully";
   }
   else
   {
       echo "Data not inserted";
       $flag=3;
   }
  }
   
   if(isset($_POST["submit"])) {
   
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
   $rollno=$_POST['rollno'];
   $std=$_POST['std'];
   $student_id=$std."_".$rollno;
   // echo $name;
   // echo $date;
   // echo $image;
   // echo $title;
   
   // echo $date;
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           echo "inside add";
               $student_id=$_POST['std'].'_'.$_POST['roll'];

         $result=mysqli_query($con,"select * from students where student_id='$student_id'");
        if(!mysqli_num_rows($result))
        {
        $result=mysqli_query($con,"insert into students values('$student_id','$_POST[std]','$_POST[roll]','$_POST[name]','$_POST[father]','$_POST[mother]','$_POST[phone1]','$_POST[email1]','$_POST[pswd]','$filename')");
        if($result){
            echo "inside insert if";
        $result1=mysqli_query($con,"select distinct(Date) from attendance_records where  student_id<>'student_id'");
        
       
        while($row=mysqli_fetch_array($result1))
        {
            echo "inside while";

           $date=$row['Date'];
            $result2=mysqli_query($con,"insert into attendance_records values('$date','$student_id','A')");
            
           
        }
        $result3=mysqli_query($con,"select * from parents where email='$_POST[email]'");
         if(mysqli_num_rows($result3)!=null){
            $result4=mysqli_query($con,"insert into parents values('$_POST[email]','$_POST[pswd]')");
            }
            else
            {
                 $result4=mysqli_query($con,"update parents set pswd='$_POST[pswd]' where email='$_POST[email]'");
            }
        }
       if($result4){
           $flag=1;
       }
       else
       {
           $flag=3;
       }
        }
   // else
   // {
   //     $result=mysqli_query($con,"update achievers set  name='$name',title='$title',description='$description',date='$date',image='$filename' where std='$std' and rollno='$rollno' and title='$title'");
   //     if($result)
   //     {
   //         $flag=2;
   //     }
   // }
   if($flag==1)
   {
       echo" data inserted successfully";
   }
   else if($flag==2)
   {
       echo "data updated successfully";
   }
   else
   {
       echo "Data not inserted";
       $flag=3;
   }
           
       } else {
           echo "Sorry, there was an error uploading your file.";
           $flag=3;
       }
   }
   }
   
   ?>
<?php ?>
 <style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}


/* starts filter search*/
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
/*ends filter search*/
</style>
<br>
<br><br><br><br>
<br>
<div class="container py-3"style="background:white">
   <div class="jumbotron">
      <h2 align="center">Add Students</h2>
   </div>
   <!-- Button to Open the Modal -->


  <!-- Trigger the modal with a button -->
 
      <div class="pull-right">
  <button type="button" class="btn btn-info  " data-toggle="modal" data-target="#myModalreport">Generate</button>
   
   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaladd">
   +Add
   </button>
  </div>

   
      <?php if($flag==1){?>
      <div class="alert alert-success">
         <strong> Success! </strong>Data added successfully
      </div>
      <?php }?>
      
         <?php if($flag==2){?>
         <div class="alert alert-success">
            <strong> Success! </strong>Data updated successfully
         </div>
         <?php }?>
         
            <?php if($flag==5){?>
            <div class="alert alert-danger">
               <strong> Yeahh!! </strong>Data deleted successfully!!
            </div>
            <?php }?>
            
               <?php if($flag==3){?>
               <div class="alert alert-danger">
                  <strong> Error! </strong>Something went Wrong!!
               </div>
               <?php }?>
<!-- Modal -->
  <!--<div class="modal fade" id="myModalreport" role="dialog">-->
  <!--  <div class="modal-dialog">-->
    
      <!-- Modal content-->
  <!--    <div class="modal-content">-->
  <!--      <div class="modal-header">-->
  <!--        <button type="button" class="close" data-dismiss="modal">&times;</button>-->
  <!--        <h4 class="modal-title">Generate Report</h4>-->
  <!--      </div>-->
  <!--      <div class="modal-body">-->
         
  <!--      </div>-->
  <!--      <div class="modal-footer">-->
  <!--        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
  <!--      </div>-->
  <!--    </div>-->
      
  <!--  </div>-->
  <!--</div>-->
  <div class="modal" id="myModalreport">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Generate Report</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <form action="stdreport.php" method="post">
             <div class="form-group">
                              <label>Std:</label>
                              <select name="std" class="form-control">
                                 <?php 
                                    $result=mysqli_query($con,"select * from std");
                                    while($row=mysqli_fetch_array($result))
                                    {
                                    ?>
                                 <option><?php echo $row['std'];?></option>
                                 <?php
                                    }
                                    ?>
                              </select>
                              <button class="btn btn-success" type="submit">Generate Report</button>
                              
            </div>
         </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
            <!-- The Modal -->
            <div class="modal fade" id="myModaladd">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <!-- Modal Header -->
                     
                     <div class="modal-header">
                        <h4 class="modal-title">Add Students</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>
                     <!-- Modal body -->
                     <div class="modal-body">
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                           
                            <div class="form-group">
                    <label for="roll">Roll Number</label>
                    <input type="number"name="roll" id="roll"  value="<?php echo $roll;?>"class="form-control" required>
                </div>
                <div class="form-group">
                              <label>Std:</label>
                              <select name="std" class="form-control">
                                 <?php 
                                    $result=mysqli_query($con,"select * from std");
                                    while($row=mysqli_fetch_array($result))
                                    {
                                    ?>
                                 <option><?php echo $row['std'];?></option>
                                 <?php
                                    }
                                    ?>
                              </select>
                              </div>
                             <div class="form-group">
                    <label for="name">Student Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="father">Father's Name</label>
                    <input type="text"name="father" id="father" value="<?php echo $father;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="mother">Mother's Name</label>
                    <input type="text"name="mother" id="mother" value="<?php echo $mother;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone1" id="phoneno"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email" name="email1" id="emailid"  value="<?php echo $email;?>"class="form-control" >
                    
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>
                <div class="form-group">
                              <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload">
                           </div>
                           <div class="form-group">
                              <center> <input type="submit" value="submit" class=" btn btn-success" name="submit"></center>
                           </div>
                        </form>
                     </div>
                     <!-- Modal footer -->
                     <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                     </div>
                  </div>
               </div>
            </div><br>
            <input type="text" id="myInput" onkeyup="myFunction()"  placeholder="Search for Standard..">
            <div class="panel panel-body table-responsive" style="overflow-x:auto;">
               <table class="table table-striped"id="myTable">
                  <tr>
                      <th>Image</th>
                      <th>Rollno</th>
                     <th>Std</th>
                     <th>Name</th>
                     <th>Father</th>
                     <th>Mother</th>
                     <th>phone</th>
                     <th>email</th>
                     <th>password</th>
                     <th>Action</th>
                  </tr>
                  <?php
                     $sql="select * from students";
                     $result=mysqli_query($con,$sql);
                     $c=0;
                     while($row=mysqli_fetch_array($result))
                     {
                         $c++;
                     $name=$row['name'];
       
        $std=$row['std'];
        
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
                     ?>
                  <tr>
                      <td><img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle" alt="Cinque Terre" width="100" height="100" style=""> </td>
                     <td><?php echo $row['rollno'];?></td>
                     <td><?php echo $row['std'];?></td>
                     <td><?php echo $row['name'];?></td>
                     <td><?php echo $row['father'];?></td>
                     <td><?php echo $row['mother'];?></td>
                     <td><?php echo $row['phone'];?></td>
                     <td><?php echo $row['email'];?></td>
                     <td><?php echo $row['pswd'];?></td>
                    
                     <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaledit<?php echo $c?>">
                        Edit
                        </button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $c?>">
                        Del
                        </button>
                     </td>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaledit<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Update Student's  Details</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                                    
                                        <div align="center">
                                        <img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle " alt="Cinque Terre" width="150" height="150">
                                        </div>
                                          <div class="form-group">
                    <label for="roll">Roll Number</label>
                    <input type="number"name="roll" id="roll"  value="<?php echo $row['rollno'];?>"class="form-control" required>
                </div>
                <div class="form-group">
                              <label>Std:</label>
                              <select name="std" class="form-control">
                                 <?php 
                                    $result1=mysqli_query($con,"select * from std");
                                    while($rows=mysqli_fetch_array($result1))
                                    {
                                    ?>
                                 <option 
                                 <?php if($row['std']==$rows['std']){ echo "selected";}?>
                                 ><?php echo $rows['std'];?></option>
                                 <?php
                                    }
                                    ?>
                              </select>
                              </div>
                                            
                     <div class="form-group">
                    <label for="name">Student Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="father">Father's Name</label>
                    <input type="text"name="father" id="father" value="<?php echo $row['father'];?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="mother">Mother's Name</label>
                    <input type="text"name="mother" id="mother" value="<?php echo $row['mother'];?>" class="form-control" >
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone1" id="phoneno"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email"name="email1" id="emailid"  value="<?php echo $email;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>
                <div class="form-group">
                              <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload"></div>
                                       <input type="hidden" name="image" value="<?php echo $row['image'];?>">
                                       <input type="hidden" name="student_id" value="<?php echo $row['student_id'];?>">
                                    
                                    <div class="form-group">
                                       <center> <input type="submit" value="Update" class=" btn btn-success" name="update"></center>
                                    </div>
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaldel<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Are you sure you want to delete theis achiever??</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="" method="post">
                                    <input type="hidden" name="student_id" value="<?php echo $row['student_id'];?>">
                                    <input type="submit" value="del" name="del" class="btn btn-danger" >
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </tr>
                  <?php
                     }
                     ?>
               </table>
            </div>
         </div>
<!--      </div>-->
<!--   </div>-->
<!--</div>-->
<?php
   if($_POST['update'])
   {
       echo $uid;
       
       echo $_FILES["fileToUpload"]["name"];
       echo " ".$update;
   }
   ?>
    <script>
        

function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}

</script>
<br>
<?php include"footer.php";
   ?>