<?php 
$con=mysqli_connect("localhost","id11184380_admin","admin","id11184380_attendance");
// $con=new PDO('mysql:host=localhost;dbname=company;charset=utf8','root','');
?>