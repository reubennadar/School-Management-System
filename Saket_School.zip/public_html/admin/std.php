<?php
include("session.php");
include("header.php");
include("db.php");
?>
<?php
if(isset($_POST['submit']))
{
   $std=$_POST['std'];
    $classroom=$_POST['classroom'];
    echo $std.$classroom;
    $result=mysqli_query($con,"select * from std where std='$std'");
    if(mysqli_num_rows($result)!=NULL)
    {
        
            //$result=mysqli_query($con,"update std set classroom='$classroom' where std='$std'");
            //$success="Standard updated successfully";
            $error="Standard already exists";

    }
    else
    {
        $result=mysqli_query($con,"insert into std values('$std','$classroom')");
        if($result)
        {
            $success=$std." Standard added successfully";
        }
        else
        {
            $error="Standard not added";
        }
        //echo $success;
    }
   
}
if(isset($_POST['edit']))
{
    $std=$_POST['estd'];
    $classroom=$_POST['eclassroom'];
    
    $result=mysqli_query($con,"update std set classroom='$classroom' where std='$std'");
    if($result)
    {
        $success=$std." Standard updated successfully";
    }
}
if(isset($_POST['del']))
{
    $std=$_POST['dstd'];
    //$classroom=$_POST['dclassroom'];
    $result=mysqli_query($con,"delete from std where std='$std'");
    if($result)
    {
        $success=$std." Standard deleted successfully";
    }
}
?>
<br><br><br><br><br>
 <div class="container py-3" style="background:white">
   <?php
      if($success)
      {
      ?>
   <div class="alert alert-success"><?php echo $success;?></div>
   <?php
      }
      ?>
   <?php
      if($error)
      {
      ?>
   <div class="alert alert-danger"><?php echo $error;?></div>
   <?php
      }
      ?>
   <div class="jumbotron">
      <h2 align="center">Add Grades/Standards</h2>
   </div>
   <!--<h2>Modal Example</h2>-->
   <!-- Button to Open the Modal -->
   <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">
   +add
   </button>
   <!-- The Modal -->
   <div class="modal fade" id="myModal">
      <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
               <h4 class="modal-title">Add Standard</h4>
               <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
               <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                  <div class="form-group">
                     <label>Std:</label>
                     <input type="text" name="std" class="form-control" placeholder="enter the std" required>
                     <label>Class Room:</label>
                     <input type="number" name="classroom" class="form-control" placeholder="enter the classroom" required>
                     <br>
                     <button type="submit" name="submit" class="btn btn-success">Submit</button>
                  </div>
               </form>
            </div>
            <!-- Modal footer -->
            <div class="modal-footer">
               <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            </div>
         </div>
      </div>
   </div>
<br>
    <div class="table-responsive">
      <table class="table">
         <tr>
            <th>Std</th>
            <th>Classroom</th>
            
            <th>Action</th>
         </tr>
         <?php
            $i=0;
            $result=mysqli_query($con,"select * from std");
            while($row=mysqli_fetch_array($result))
            {
                $i=$i+1;
            ?>
         <tr>
            <td><?php echo $row['std'];?></td>
            <td><?php echo $row['classroom'];?></td>
            
            <td>
             <form action="stdreport.php" method="post" class="pull-left">
                <input type="hidden" name="std" value="<?php echo $row['std'];?>">
                <button type="submit" class="btn btn-info ">Report</button>
                &nbsp;

            </form>
                
               <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaledit<?php echo $i;?>">
               Edit
               </button>
               <!-- The Modal -->
               <div class="modal fade" id="myModaledit<?php echo $i;?>">
                  <div class="modal-dialog modal-dialog-centered">
                     <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                           <h4 class="modal-title">Edit Standard</h4>
                           <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <!-- Modal body -->
                        <div class="modal-body">
                           <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method='post'>
                               <div class="form-group">
                                   <label>Std:</label>
                                   <input type="text" name="estd" value="<?php echo $row['std'];?>"class="form-control" readonly>
                                   <label>Classroom</label>
                                   <input type="text" name="eclassroom" value="<?php echo $row['classroom']?>"class="form-control">
                                   <input type="submit" value="edit" name="edit" class="btn btn-primary">
                               </div>
                           </form>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>
               <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $i;?>">
               Del
               </button>
               <!-- The Modal -->
               <div class="modal fade" id="myModaldel<?php echo $i;?>">
                  <div class="modal-dialog modal-dialog-centered">
                     <div class="modal-content">
                        <!-- Modal Header -->
                        <div class="modal-header">
                           <h4 class="modal-title">Do you really want to delete ?</h4>
                           <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <!-- Modal body -->
                        <div class="modal-body">
                          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                              <div class="form-group">
                                  <input type="hidden" name="dstd" value="<?php echo $row['std'];?>" >
                                  <button type="submit" name="del" class="btn btn-success">Delete</button>
                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                              </div>
                          </form>
                        </div>
                        <!-- Modal footer -->
                        <div class="modal-footer">
                           <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                     </div>
                  </div>
               </div>
               
               
            </td>
         </tr>
         <?php 
            }
            ?>
      </table>
   </div>
</div>
<?php

?>
<?php
include("footer.php");
?>