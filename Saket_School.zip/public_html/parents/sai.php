<?php
include("db.php");
$flag=0;
$flag2=0;
session_start();

if(!isset($_SESSION['$USER']))
{
    header("Location:login.php");    
}
if(isset($_POST['logout'])){
    session_destroy();
}
// if(isset($_POST['submit']))
// {
    
//     echo "inside if statement";
//     $counter=0;
//     foreach($_POST['attendance_status'] as $id=>$attendance_status){
//         echo " inside foreach";
       
       
//          $name=$_POST['name'][$id];
//          echo $name;
//         $rollno=$_POST['rollno'][$id];
//         $date=$_POST['cdate'];
//         $std=$_POST['std'];
//         echo $std;
//         $div=$_POST['div'];
//         $result=mysqli_query($con,"select * from attendance_records where Date='$date' and rollno='$rollno' and std='$std' and division ='$div'");
//         if(!mysqli_num_rows($result))
//         {
//           //  echo "inside num rows";
//         $result= mysqli_query($con,"insert into attendance_records values('$date','$std','$div','$rollno','$name','$attendance_status')");
//         //$my=mysqli_query($con,"insert into attendance_records values('$date','$rollno','$name','$attendance_status')");
//         if($result)
//         {
//             $flag=1;
//         }
                
//         }
//         else
//         {
//             $result=mysqli_query($con,"update attendance_records set attendance_status='$attendance_status' where Date='$date' and rollno='$rollno' and division='$div' and std='$std'");
//              if($result)
//         {
//             $flag2=1;
//         }
//         $counter++;
            
//         }
//     }
//     //mysqli_query($con,"insert into attendance_records values('01/20/22',12,'Reuben','present')");
// }
?>
<html>
    <head>
        <title>Saket | DB_INDEX</title>
            <!-- Latest compiled and minified CSS -->
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

            <!-- jQuery library -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

            <!-- Latest compiled JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container">
            <div class="well text-center"><h2> Student/ Employee Attendance System</h2></div>
            <div class="panel panel-default">
                <div class="panel panel-heading">
                    <h2>
                    
                    <form action="sai.php" method="post">
                        <a class="btn btn-success" href="registerstudent.php">Add Students</a>
                    <input type="submit" class="btn btn-info pull-right" value="Logout"name="logout"> 
                    </form>
                    </h2>
                    <?php
                    if($flag){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  inserted successfully
                    </div>
                    <?php
                    }
                    ?>
                    <?php
                    if($flag2){
                    ?>
                    <div class="alert alert-success">
                        Attendance  data  Updated successfully
                    </div>
                    <?php
                    }
                    ?>
                     <?php 
                     //echo date("Y-m-d");
                     ?>
                    <form action="sai.php" method="post">
                        Std:<input type="number" name="std">
                        Division:<input type="text"name="div">
                        Rollno: <input type="text" name="rollno">
                        <button  value="submit" name="submit">search</button>
                    </form>
                    
                    
                        
                                    <div class="panel panel-body">
                        <table class="table table-striped">
                            <tr>
                            <th>#Serial no</th>
                            <th>Rollno</th>
                            <th> Date</th>
                            <th>Attendance Status</th>
                            </tr>
                            <?php
                              //if(isset($_POST['info']))  
                              //{
                                $counter=0;
                                $std=$_POST['std'];
                                echo $std;
                                $div=$_POST['div'];
                                $rollno=$_POST['rollno'];
                                echo $div;
                                echo $rollno;
                                $result=mysqli_query($con,"select * from attendance_records where std='$std' and division='$div' and rollno='$rollno'");
                                while($row=mysqli_fetch_array($result))
                                {
                                    
                            ?>
                            <tr>
                            <td><?php echo $counter+1?></td>
                            <td><?php echo $row['rollno']?></td>
                            <td><?php echo $row['Date']?></td>
                            <td><?php echo $row['attendance_status']?>
                            </td>
                            </tr>   
                            <?php
                                $counter++;
                                }
                             
                            ?>


                        </table>

                </div>

                </div>
                
                            
                
            </div>
        </div>
    </body>
</html>