<?php
 $std=$_POST['std'];
 include "db.php";
 //echo "success";
 //echo $std;
 ?>
 
     <label>Subject</label>
     <select class="form-control" name="subject">
         <?php
 $result=mysqli_query($con,"select * from subject where std='$std'");
 while($row=mysqli_fetch_array($result))
 {
?>
 <option><?php echo $row['name'];?>
             
         </option>
<?php
 }
 ?>
        
     </select>
 
 