<?php include("db.php");
include("session.php");

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
$id=$_POST["id"];
$title=$_POST['title'];
$date=$_POST['date'];
$image=$_POST['fileToUpload'];
echo $id;
echo $date;
echo $image;
echo $title;
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

// Check if file already exists
// if (file_exists($target_file)) {
//     echo "Sorry, file already exists.";
//     $uploadOk = 0;
// }
// Check file size
// if ($_FILES["fileToUpload"]["size"] > 500000) {
//     echo "Sorry, your file is too large.";
//     $uploadOk = 0;
// }
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        $filename=basename( $_FILES["fileToUpload"]["name"]);
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        $result=mysqli_query($con,"select * from updates where id='$id'");
        while($row=mysqli_fetch_array($result))
        {
            echo "new title is ......".$row['title'];
        }

$flag=0;
if(!mysqli_num_rows($result))
{ echo "inside if ";
    $result=mysqli_query($con,"insert into updates values('$id','$title','$date','$filename')");
    //  $result= mysqli_query($con,"insert into updates values('Event-2','Hello everyone','1999-12-09','img.jpg')");
    $flag=1;
}
else
{
    $result=mysqli_query($con,"update updates set title='$title',date='$date',image='$filename' where id='$id'");
    $flag=2;
}
if($flag==1)
{
    echo" data inserted successfully";
}
else if($flag==2)
{
    echo "data updated successfully";
}
else
{
    echo "Data not inserted";
}
        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
}
?>

<?php include"header.php";?>
<br>
<br><br><br><br>
<br>
<div class="container">
    <div class="jumbotron">
        <h2 align="center">Add Updates, Events and Notices</h2>
    </div>
    <div class="panel panel-default">
            <?php if($flag==1){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Data added successfully
            </div>    
            <?php }?>
            <div class="panel panel-default">
            <?php if($flag==2){?>
            <div class="alert alert-success">
                <strong> Success! </strong>Data updated successfully
            </div>    
            <?php }?>
             
            <div class="panel panel-default">
            <?php if($uploadOk ==0){?>
            <div class="alert alert-danger">
                <strong> Error! </strong>Something went Wrong!!
            </div>  
             <?php }?>
    </div>
</div>
<div class="container">
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
            <div class="form-group">
       <label>ID:</label> <select name="id" class="form-control">
                <option>Event-1</option>
                <option>Event-2</option>
                <option>Event-3</option>
                <option>Notice-1</option>
                <option>Notice-2</option>
                <option>Notice-3</option>
                <option>Notice-4</option>
                <option>Notice-5</option>
                <option>Notice-6</option>
                <option>News-1</option>
                <option>News-2</option>
                <option>News-3</option>
                
            </select>
             <label>Title</label><input type="text" class="form-control"name="title">
              <label>Date</label><input type="date"class="form-control" name="date">
        <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload">
        
            </div>
       
       <div class="form-group">
          <center> <input type="submit" value="submit" class=" btn btn-success" name="submit"></center>
       </div>
        </form>
        </div>
   <?php include "footer.php";?>