 <?php
include "simple_html_dom.php";
$dom=file_get_html('https://mumbaimirror.indiatimes.com/',false);
$ret=$dom->find('div.column2 ul',0);
//echo $ret;

// foreach($ret->find('li a') as $element)
// {
//     echo $element->plaintext;
//     echo $element->href;
//     echo "<br>";
// }
$ret=$dom->find('div.column2 ul',0);
foreach($ret->find('li a') as $element)
{
    $plaintext=$element->plaintext;
    echo $plaintext;
    echo "<br>";
    $url=$element->href;
    
    echo "https://mumbaimirror.indiatimes.com".$url;
    echo "<br>";
    $href="https://mumbaimirror.indiatimes.com".$url;
    $dom1=file_get_html($href);
    $get=$dom1->find('title',0);
    
    echo $get->plaintext;
    echo "<br>";
    $img=$dom1->find('img[title]',0);
    echo $img->src;
    echo "<br><br>";
}
// <img defer="defer" alt="Solitary refinement" title="Solitary refinement" src="https://static.toiimg.com/thumb/imgsize-167741,msid-74903056,width-400,resizemode-4/74903056.jpg" pg="">

?>
