<?php

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html="<h1>Saket School Attendance Management Reports</h1>";

$dompdf=new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','landscape');
$dompdf->render();
$dompdf->stream('new',array("Attachement"=>0));
?>




