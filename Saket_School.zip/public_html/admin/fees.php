<?php include "session.php";
include "config.php";
include "header.php";
?>
<br><br><br><br><br>
<div class="container py-3" style="background:white;">
    <div class="jumbotron">
        <h1 align="center">Payment of fees</h1>
    </div>
    <link href="https://unpkg.com/bootstrap-table@1.16.0/dist/bootstrap-table.min.css" rel="stylesheet">

<script src="https://unpkg.com/bootstrap-table@1.16.0/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.16.0/dist/extensions/multiple-sort/bootstrap-table-multiple-sort.js"></script>

<table
  id="table"
  data-search="true"
  data-show-columns="true"
  data-show-multi-sort="true"
  data-sort-priority='[{"sortName": "github.count.forks","sortOrder":"desc"},{"sortName":"github.count.stargazers","sortOrder":"desc"}]'
  data-url="json/data3.json">
  <thead>
    <tr>
      <th data-field="github.name" data-sortable="true">Name</th>
      <th data-field="github.count.stargazers" data-sortable="true">Stargazers</th>
      <th data-field="github.count.forks" data-sortable="true">Forks</th>
      <th data-field="github.description" data-sortable="true">Description</th>
    </tr>
     
  </thead>
  <tbody>
      <tr>
      <td>Hello</td>
      <td>Hello</td>
      <td>Hello</td>
      <td>Hello</td>
      
  </tr>
  </tbody>
 
</table>

<script>
  $(function() {
    $('#table').bootstrapTable()
  })
</script>
</div>

<?php include "footer.php"?>