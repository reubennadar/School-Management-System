<?php

require_once "dompdf/autoload.inc.php";
use Dompdf\Dompdf;
$html='<html><head>
                <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
                </head><body><h1 align="center">Attendance Records of Saket Vidya Mandir</h1>';
$std=$_POST['std'];

$html.='<h3 align="center">'.$std." ".$from." to".$to.'</h3>';

include("db.php");
// if(isset($std,$from,$to))
// {
    $result=mysqli_query($con,"select * from students where  std='$std'");
     $html.='
                <table class="table">
                <tr>
                <th>Rollno</th>
                <th>Name</th>
                <th>Father</th>
                <th>Mother</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Password</th>
                ';
                
    $html.='</tr>
            ';
            
   
    while($row=mysqli_fetch_array($result))
    {
        $rollno=$row['rollno'];
        $name=$row['name'];
        $father=$row['father'];
        $mother=$row['mother'];
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
        $student_id=$std."_".$rollno;
        $html.='<tr>
            <td>'.$rollno.'</td>
        <td>'.$name.'</td>
        <td>'.$father.'</td>
        <td>'.$mother.'</td>
        <td>'.$phone.'</td>
        <td>'.$email.'</td>
        <td>'.$pswd.'</td>';
      
        $html.='</tr>';
    }
        $html.='</table></body></html>';
// }
$dompdf=new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4','Portrait');
$dompdf->render();
$dompdf->stream('Std Report',array("Attachement"=>0));
?>




