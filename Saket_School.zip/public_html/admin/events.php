<?php include("db.php");
   include("session.php");
   include("header.php");
   
   
   $target_dir = "uploads/";
   $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
   $uploadOk = 1;
   $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   // Check if image file is a actual image or fake image
   if(isset($_POST['del']))
   {
       $event_id=$_POST['event_id'];
       $sql="delete from events where event_id='$event_id'";
       $result=mysqli_query($con,$sql);
       if($result){
           $flag=5;
       }
       
       else
       {
           $flag=3;
       }
   }
   if(isset($_POST['update']))
   {
       
       
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
   $event_id=$_POST['event_id'];
  if($_FILES["fileToUpload"][name]==null)
  {
      $update="inside no wala";
         $sql="update events set title='$title',description='$description' where event_id='$event_id'";
    //$sql="update event set title='$title' where event_id='$event_id'";
    $result=mysqli_query($con, $sql);
    if($result)
    {
        $flag=2;
    }
    
  }
  else
  {
   
   $update="inside else wala ";
   // echo $name;
   // echo $date;
   // echo $image;
   // echo $title;
   
   // echo $date;
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           
   
   $title=$_POST['title'];
   $description=$_POST['description'];
    $sql="update events set title='$title',description='$description',image='$filename' where event_id='$event_id'";
    //$sql="update event set title='$title' where event_id='$event_id'";
    $result=mysqli_query($con, $sql);
    if($result)
    {
        $flag=2;
    }
    
   }
   
   }
   if($flag==2)
   {
       echo "data updated successfully";
   }
   else
   {
       echo "Data not inserted";
       $flag=3;
   }
  }
   }
   if(isset($_POST["submit"])) {
   
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
 
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
          
   
   $flag=0;
 
       $result=mysqli_query($con,"insert into events (title,description,image) values('$title','$description','$filename')");
       //  $result= mysqli_query($con,"insert into updates values('Event-2','Hello everyone','1999-12-09','img.jpg')");
       if($result)
       {
           $flag=1;
       }
   
   // else
   // {
   //     $result=mysqli_query($con,"update event set  name='$name',title='$title',description='$description',date='$date',image='$filename' where std='$std' and rollno='$rollno' and title='$title'");
   //     if($result)
   //     {
   //         $flag=2;
   //     }
   // }
   if($flag==1)
   {
       echo" data inserted successfully";
   }
   else if($flag==2)
   {
       echo "data updated successfully";
   }
   else
   {
       echo "Data not inserted";
       $flag=3;
   }
           
       } else {
           echo "Sorry, there was an error uploading your file.";
           $flag=3;
       }
   }
   }
   
   ?>
<?php ?>
<br>
<br><br><br><br>
<br>
<div class="container py-3" align="center" style="background:white">
   <div class="jumbotron">
      <h2 align="center">Add events</h2>
   </div>
   <!-- Button to Open the Modal -->

   <button type="button" class="btn btn-primary text-center" data-toggle="modal" data-target="#myModaladd">
   +Add
   </button>

   <br>
      <?php if($flag==1){?>
      <div class="alert alert-success">
         <strong> Success! </strong>event added successfully
      </div>
      <?php }?>
      
         <?php if($flag==2){?>
         <div class="alert alert-success">
            <strong> Success! </strong>event updated successfully
         </div>
         <?php }?>
         
            <?php if($flag==5){?>
            <div class="alert alert-danger">
               <strong> Yeahh!! </strong>event deleted successfully!!
            </div>
            <?php }?>
            
               <?php if($flag==3){?>
               <div class="alert alert-danger">
                  <strong> Error! </strong>Something went Wrong!!
               </div>
               <?php }?>
            
            <!-- The Modal -->
            <div class="modal fade" id="myModaladd">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <!-- Modal Header -->
                     <div class="modal-header">
                        <h4 class="modal-title">Add events</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>
                     <!-- Modal body -->
                     <div class="modal-body">
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                           <div class="form-group">
                              
                             
                              <label>Title</label><input type="text" class="form-control"name="title">
                              <label>Description</label><textarea class="form-control" name="description"></textarea>
                              <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload">
                              
                           </div>
                           <div class="form-group">
                              <center> <input type="submit" value="submit" class=" btn btn-success" name="submit"></center>
                           </div>
                        </form>
                     </div>
                     <!-- Modal footer -->
                     <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                     </div>
                  </div>
               </div>
            </div>
            <div class="panel panel-body" style="overflow-x:auto;">
               <table class="table table-striped table-responsive">
                  <tr>
                      <th>Image</th>
                     <th>Title</th>
                     <th>Description</th>
                     <th>Action</th>
                  </tr>
                  <?php
                     $sql="select * from events ";
                     $result=mysqli_query($con,$sql);
                     $c=0;
                     while($row=mysqli_fetch_array($result))
                     {
                         $c++;
                     
                     ?>
                  <tr>
                      <td><img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle" alt="Cinque Terre" width="100" height="100" style=""> </td>
                    
                     <td><?php echo $row['title'];?></td>
                     <td><?php echo $row['description'];?></td>
                    
                     <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaledit<?php echo $c?>">
                        Edit
                        </button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $c?>">
                        Del
                        </button>
                     </td>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaledit<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Update Achiever Details</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                                    <div class="form-group">
                                        <div align="center">
                                        <img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle " alt="Cinque Terre" width="150" height="150">
                                        </div>
                                       
                                       <label>Title</label><input type="text" class="form-control"name="title" value="<?php echo $row['title'];?>">
                                       <label>Description</label><input type="text"class="form-control" name="description" value="<?php echo $row['description'];?>">
                                       <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload" value="<?php echo $row['image'];?>">
                                       <input type="hidden" name="image" value="<?php echo $row['image'];?>">
                                       <input type="hidden" name="event_id" value="<?php echo $row['event_id'];?>">
                                    </div>
                                    <div class="form-group">
                                       <center> <input type="submit" value="Update" class=" btn btn-success" name="update"></center>
                                    </div>
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaldel<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Are you sure you want to delete theis achiever??</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="" method="post">
                                    <input type="hidden" name="event_id" value="<?php echo $row['event_id'];?>">
                                    <input type="submit" value="del" name="del" class="btn btn-danger" >
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </tr>
                  <?php
                     }
                     ?>
               </table>
            </div>
         </div>
<!--      </div>-->
<!--   </div>-->
<!--</div>-->
<?php
   if($_POST['update'])
   {
       echo $event_id;
       echo $title;
       echo $description;
       echo $image;
       echo $_FILES["fileToUpload"]["name"];
       echo " ".$update;
   }
   ?>
<?php include"footer.php";
   ?>