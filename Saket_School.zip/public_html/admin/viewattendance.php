<?php include "db.php"?>
<?php include "session.php"?>
<?php include "header.php"?>
<br><br><br><br><br>
<div class="container py-3" style="background:white">
    <div class="jumbotron">
        <h1 align="center">View Attendance</h1>
    </div>
  <div class="table-responsive">
    <table class="table table-striped">
        <tr>
            <th>Month</th>
            <th>View</th>
            <th>Report</th>
        </tr>
        
            <?php
            $result=mysqli_query($con,"select DISTINCT MONTHNAME(Date) as month from attendance_records where student_id like 'Tuition_%'");
            while($row=mysqli_fetch_array($result))
            {
                
            ?>
            <tr>
                <td><?php echo $row['month'];?></td>
                <td><span class="fa fa-eye"></span></td>
                <td><span class="fa fa-download"></span></td>
            </tr>
            <?php
                
            }
            ?>
      
       
    </table>
  </div>
</div>

<?php include "footer.php"?>