<?php 
include "db.php";
include "session.php";
include "header.php";
if($_POST['submit'])
{
    $remark_id=$_POST['remark_id'];
    $result=mysqli_query($con,"update remarks set status='seen' where remark_id='$remark_id'");
    if($result)
    {
        $me="inside submit";
    }
}
?>
<?php
                    
                    ?>
                    <br><br><br><br>
<div class="container py-3" style="background:white">
    <div class="jumbotron">
        <h2 align="center"> Remarks</h2>
    </div>
<div class="table-responsive">
    <table class=" table table-striped">
        <tr>
            <th>Date</th>
            <th>Remark</th>
            <th>Seen/Unseen</th>
            
        </tr>
        <?php
        $result=mysqli_query($con,"select * from remarks  where remarks.student_id='$student_id' order  by remarks.Date desc ");
        while($row=mysqli_fetch_array($result))
        {
            $date=date("d-M,D", strtotime($row['Date']));
            $student_id=$row['student_id'];
            $remark=$row['remark'];
            $name=$row['name'];
            $status=$row['status'];
            $rollno=$row['rollno'];
            $std=$row['std'];
            $remark_id=$row['remark_id'];
        ?>
        <tr>
        <td><?php echo $date;?></td>
        
        <td><?php echo $remark;?></td>
        <td><?php if($status=='seen')
        {
        ?>
        <button class="btn btn-success"><?php echo $status;?></button>
        <?php
        }
        else
        {
        
        ?>
         <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"> 
         <input type="hidden" value="<?php echo $remark_id;?>" name="remark_id">
        <input type="submit" value="Mark as read"class="btn btn-primary" name="submit">
        </form>
        <?php
        }
        ?>
        </td>
        
        
        
        
        </tr>
        <?php
        }
        ?>
    </table>
    </div>
</div><br>
<?php 
include "footer.php";
?>