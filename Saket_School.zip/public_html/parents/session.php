<?php
session_start();

if(!isset($_SESSION['$PARENT']))
{
    header("Location:login");    
}
else
{
    
    $email=$_SESSION['$PARENT'];
                    $result=mysqli_query($con,"select * from students where email='$email'");
                    while($row=mysqli_fetch_array($result))
                    {
                        $std=$row['std'];
                        $name=$row['name'];
                        $rollno=$row['rollno'];
                        $student_id=$std."_".$rollno;
                        $father=$row['father'];
                        
                    }
}

?>