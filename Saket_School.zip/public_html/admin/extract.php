<?php
$data_scrapped=file_get_contents('https://timesofindia.indiatimes.com/');
//echo $data_scrapped;
$part=explode('<a pg="#Story_View-2-geturl~Top_News_Stories" title="Corona updates: India reports 649 cases" href="/india/coronavirus-india-latest-developments-at-least-60-daily-cases-in-past-five-days/articleshow/74820870.cms">Corona updates: India reports 649 cases</a>',$data_scrapped);
$html = file_get_html('https://timesofindia.indiatimes.com');
$ret=$html->find('div[id=featuredstory]');

echo $ret->plaintext;

?>