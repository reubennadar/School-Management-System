<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include "session.php";
include "header.php";
$c=0;
include "db.php";
$flag=0;
if($_POST['add'])
{
    $std=$_POST['std'];
    $rollno=$_POST['rollno'];
    $student_id=$std.'_'.$rollno;
    $remark=$_POST['remark'];
    $result=mysqli_query($con,"insert into remarks (student_id,remark) values('$student_id','$remark')");
    if($result)
    {
        $flag=1;
    }
    
$result=mysqli_query($con,"select * from students where student_id='$student_id'");
while($row=mysqli_fetch_array($result))
{
    $email=$row['email'];
}

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);

try {
    
    $mail->setFrom('reuben.nadar99@gmail.com', 'Saket School');
    $mail->addAddress($email,$name);     // Add a recipient
    
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Remark';
    $mail->Body    = '<b>'.$remark.'</b>';
    $mail->AltBody = 'Ennai da ena unaku ena venum';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
    
}
if($_POST['submit'])
{
    
    $remark_id=$_POST['remark_id'];
    
    $result=mysqli_query($con,"delete from remarks where remark_id='$remark_id' ");
    if($result)
    {
        $flag=2;
    }
    
}
?> <br>
    <br>
    <br><br>
    <br>
<div class="container py-3" style="background:white">
   
    <div class="jumbotron">
      <h2 align="center">Add Remarks</h2>
     </div>
    <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">+Add</button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Add Remarks</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
              <div class="form-group">
                  <label>Std</label>
                    <select class="form-control" name="std" required>
                        <?php 
                        $result=mysqli_query($con,"select * from std");
                        while($row=mysqli_fetch_array($result))
                        {
                        ?>
                        <option value="<?php echo $row['std'];?>"><?php echo $row['std'];?> </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                    <label>Rollno</label>
                    <input type='number' class="form-control" name="rollno">
              <label>Remark</label>
              <textarea class="form-control" name="remark" placeholder="Please enter the remark"></textarea>
              
              </div>
              <input type="submit" value="add" name="add"class="btn btn-success">
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

    <?php 
    if($flag==1)
    {
    ?>
    <div class="alert alert-success">
        Success! Remark has been added
    </div>
    <?php
    }
    ?>
<div class="table-responsive">
    <table class="table table-striped">
        <tr>
            <th>Date</th>
            <th>Remark ID</th>
            <th>Std</th>
            <th>Rollno</th>
            <th>Name</th>
            <th>Remark</th>
            <th>Seen/Unseen</th>
            <th>Action</th>
        </tr>
        <?php
        $result=mysqli_query($con,"select * from remarks,students where remarks.student_id=students.student_id order  by remarks.Date desc ");
        while($row=mysqli_fetch_array($result))
        {
            $date=date("d-M,D", strtotime($row['Date']));
            
            $student_id=$row['student_id'];
            $remark=$row['remark'];
            $name=$row['name'];
            $status=$row['status'];
            $rollno=$row['rollno'];
            $std=$row['std'];
            $remark_id=$row['remark_id'];
        ?>
        <tr>
        <td><?php echo $date;?></td>
        <td><?php echo $remark_id?></td>
        <td><?php echo $std;?></td>
        <td><?php echo $rollno;?></td>
        <td><?php echo $name;?></td>
        <td><?php echo $remark;?></td>
        <td><?php if($status=='seen')
        {
        ?>
        <h4><span class="label label-success"><?php echo $status;?></span></h4>
        <?php
        }
        else
        {
        
        ?>
        <h4><span class="label label-danger"><?php echo $status;?></span></h4>
        </td>
        <?php
        }
        
        
        ?>
        <td>
            <?php $c=$c+1; ?>
             <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $c;?>">-del</button>

<!-- Modal -->
<div id="myModaldel<?php echo $c;?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      
      <div class="modal-body">
          
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="container">
         <h1>Delete Remark</h1>
      <p>Are you sure you want to delete?</p>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                          <input type="hidden" value="<?php echo $remark_id;?>" name="remark_id">
            <button type="button" class="btn btn-info btn-lg"  data-dismiss="modal">Cancel</button>
              <input type="submit" value="Delete" name="submit"class="btn btn-danger btn-lg">
          </form>
 
        
       
      </div>
     </div>
    </div>

  </div>
</div>

       
        </td>
        
        </tr>
        <?php
        }
        ?>
    </table>
    </div>
</div><br>
<?php 
include "footer.php";
?>