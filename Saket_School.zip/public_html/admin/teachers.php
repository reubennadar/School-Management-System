<?php include("db.php");
   include("session.php");
   include("header.php");
   
   
   $target_dir = "uploads/";
   $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
   $uploadOk = 1;
   $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   // Check if image file is a actual image or fake image
   if(isset($_POST['del']))
   {
       $achievers_id=$_POST['achievers_id'];
       $sql="delete from teachers where uid='$_POST[uid]'";
       $result=mysqli_query($con,$sql);
       if($result){
           $flag=5;
       }
       
       else
       {
           $flag=3;
       }
   }
   if(isset($_POST['update']))
   {
       
       
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
   $achievers_id=$_POST['achievers_id'];
  if($_FILES["fileToUpload"][name]==null)
  {
      $update="inside no wala";
 $result=mysqli_query($con,"update teachers set name='$_POST[name]',std='$_POST[std]',phone='$_POST[phone]',email='$_POST[email]',pswd='$_POST[pswd]' where  uid='$_POST[uid]'");
            if($result)
            {
                $flag=2;
            }
    
  }
  else
  {
   
   $update="inside else wala ";
   // echo $name;
   // echo $date;
   // echo $image;
   // echo $title;
   
   // echo $date;
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     //echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       //echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           
   
   $title=$_POST['title'];
   $description=$_POST['description'];
     $result=mysqli_query($con,"update teachers set name='$_POST[name]',std='$_POST[std]',phone='$_POST[phone]',email='$_POST[email]',pswd='$_POST[pswd]',image='$filename' where uid='$_POST[uid]'");
            if($result)
            {
                $flag=2;
            }
    
   }
   
   }
   if($flag==2)
   {
       //echo "data updated successfully";
   }
   else
   {
       //echo "Data not inserted";
       $flag=3;
   }
  }
   }
   if(isset($_POST["submit"])) {
   
   $title=$_POST['title'];
   $description=$_POST['description'];
   $image=$_POST['fileToUpload'];
   $rollno=$_POST['rollno'];
   $std=$_POST['std'];
   $student_id=$std."_".$rollno;
   // //echo $name;
   // //echo $date;
   // //echo $image;
   // //echo $title;
   
   // //echo $date;
       $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
       if($check !== false) {
           //echo "File is an image - " . $check["mime"] . ".";
           $uploadOk = 1;
       } else {
           //echo "File is not an image.";
           $uploadOk = 0;
       }
   
   // Check if file already exists
   // if (file_exists($target_file)) {
   //     //echo "Sorry, file already exists.";
   //     $uploadOk = 0;
   // }
   // Check file size
   // if ($_FILES["fileToUpload"]["size"] > 500000) {
   //     //echo "Sorry, your file is too large.";
   //     $uploadOk = 0;
   // }
   // Allow certain file formats
   if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
   && $imageFileType != "gif" ) {
       //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
       $uploadOk = 0;
   }
   // Check if $uploadOk is set to 0 by an error
   if ($uploadOk == 0) {
       //echo "Sorry, your file was not uploaded.";
   // if everything is ok, try to upload file
   } else {
       if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
           $filename=basename( $_FILES["fileToUpload"]["name"]);
           //echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           //echo "inside add";
        $result=mysqli_query($con,"select * from teachers where uid='$_POST[uid]'");
        if(!mysqli_num_rows($result))
        {
            //echo "inside num rows";
        $result=mysqli_query($con,"insert into teachers(uid,std,name,phone,email,pswd,image)values('$_POST[uid]','$_POST[std]','$_POST[name]','$_POST[phone]','$_POST[email]','$_POST[pswd]','$filename')");
        if($result)
        {
             $flag=1;
        }
       
        }
   // else
   // {
   //     $result=mysqli_query($con,"update achievers set  name='$name',title='$title',description='$description',date='$date',image='$filename' where std='$std' and rollno='$rollno' and title='$title'");
   //     if($result)
   //     {
   //         $flag=2;
   //     }
   // }
   if($flag==1)
   {
       //echo" data inserted successfully";
   }
   else if($flag==2)
   {
       //echo "data updated successfully";
   }
   else
   {
       //echo "Data not inserted";
       $flag=3;
   }
           
       } else {
           //echo "Sorry, there was an error uploading your file.";
           $flag=3;
       }
   }
   }
   
   ?>
<?php ?>
<br>
<br><br><br><br>
<br>
<div class="container py-3" style="background:white" align="center">
   <div class="jumbotron">
      <h2 align="center">Add Teachers</h2>
   </div>
   <!-- Button to Open the Modal -->

   
   <form action="teacherreport.php" class="text-center">
   <button type="submit" class="btn btn-info">
   Generate
   </button>
    
   </form>
   <br>
   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaladd">
   +Add
   </button>

   
      <?php if($flag==1){?>
      <div class="alert alert-success">
         <strong> Success! </strong>Data added successfully
      </div>
      <?php }?>
      
         <?php if($flag==2){?>
         <div class="alert alert-success">
            <strong> Success! </strong>Data updated successfully
         </div>
         <?php }?>
         
            <?php if($flag==5){?>
            <div class="alert alert-danger">
               <strong> Yeahh!! </strong>Data deleted successfully!!
            </div>
            <?php }?>
            
               <?php if($flag==3){?>
               <div class="alert alert-danger">
                  <strong> Error! </strong>Something went Wrong!!
               </div>
               <?php }?>
            
            <!-- The Modal -->
            <div class="modal fade" id="myModaladd">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <!-- Modal Header -->
                     <div class="modal-header">
                        <h4 class="modal-title">Add Teachers</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>
                     <!-- Modal body -->
                     <div class="modal-body">
                        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                           
                                               <div class="form-group">
                    <label for="uid">UID</label>
                    <input type="number"name="uid" id="uid"  value="<?php echo $uid;?>"class="form-control" required>
                </div>
                <div class="form-group">
                              <label>Std:</label>
                              <select name="std" class="form-control">
                                 <?php 
                                    $result=mysqli_query($con,"select * from std");
                                    while($row=mysqli_fetch_array($result))
                                    {
                                    ?>
                                 <option><?php echo $row['std'];?></option>
                                 <?php
                                    }
                                    ?>
                              </select>
                              </div>
                             <div class="form-group">
                    <label for="name">Teacher's Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
               
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone" id="phoneno"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email"name="email" id="emailid"  value="<?php echo $email;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>
                <div class="form-group">
                              <label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload">
                           </div>
                           <div class="form-group">
                              <center> <input type="submit" value="submit" class=" btn btn-success" name="submit"></center>
                           </div>
                        </form>
                     </div>
                     <!-- Modal footer -->
                     <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                     </div>
                  </div>
               </div>
            </div>
            <br><br>
            <div class="panel panel-body table-responsive" style="overflow-x:auto;">
               <table class="table table-striped">
                  <tr>
                      <th>Image</th>
                      <th>UID</th>
                     <th>Std</th>
                     <th>Name</th>
                     <th>phone</th>
                     <th>email</th>
                     <th>password</th>
                     <th>Action</th>
                  </tr>
                  <?php
                     $sql="select * from teachers";
                     $result=mysqli_query($con,$sql);
                     $c=0;
                     while($row=mysqli_fetch_array($result))
                     {
                         $c++;
                     $name=$row['name'];
        $uid=$row['uid'];
        $std=$row['std'];
        
        $phone=$row['phone'];
        $email=$row['email'];
        $pswd=$row['pswd'];
                     ?>
                  <tr>
                      <td><img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle" alt="Cinque Terre" width="100" height="100" style=""> </td>
                     <td><?php echo $row['uid'];?></td>
                     <td><?php echo $row['std'];?></td>
                     <td><?php echo $row['name'];?></td>
                     <td><?php echo $row['phone'];?></td>
                     <td><?php echo $row['email'];?></td>
                     <td><?php echo $row['pswd'];?></td>
                    
                     <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModaledit<?php echo $c?>">
                        Edit
                        </button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModaldel<?php echo $c?>">
                        Del
                        </button>
                     </td>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaledit<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Update Teacher's  Details</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"enctype="multipart/form-data">
                                    
                                        <div align="center">
                                        <img src="uploads/<?php echo $row['image'];?>" class=" img-responsive img-thumbnail img-circle " alt="Cinque Terre" width="150" height="150">
                                        </div>
                                        <div class="form-group">
                    <label for="uid">UID</label>
                    <input type="number"name="uid" id="uid"  value="<?php echo $uid;?>"class="form-control" required readonly>
                </div>
                 <div class="form-group">
                              <label>Std:</label>
                              <select name="std" class="form-control">
                                 <?php 
                                    $result2=mysqli_query($con,"select * from std");
                                    while($rows=mysqli_fetch_array($result2))
                                    {
                                    ?>
                                 <option 
                                 <?php if($row['std']==$rows['std']){ echo "selected";} ?>
                                 ><?php echo $rows['std'];?></option>
                                 <?php
                                    }
                                    ?>
                              </select>
                              </div>
                               <div class="form-group">
                    <label for="name">Teacher's Name</label>
                    <input type="text"name="name" id="name" value="<?php echo $name;?>" class="form-control" >
                </div>
               
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="number"name="phone" id="phoneno"  value="<?php echo $phone;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="email">Email Id</label>
                    <input type="email"name="email" id="emailid"  value="<?php echo $email;?>"class="form-control" >
                </div>
                <div class="form-group">
                    <label for="pswd">Password</label>
                    <input type="password"name="pswd" id="pswd"  value="<?php echo $pswd;?>"class="form-control" >
                </div>        
                  <div class="form-group"><label>Image</label><input type="file" class="form-control" name="fileToUpload"id="fileToUpload" value="<?php echo $row['image'];?>"></div>
                                       <input type="hidden" name="image" value="<?php echo $row['image'];?>">
                                       
                                    
                                    <div class="form-group">
                                       <center> <input type="submit" value="Update" class=" btn btn-success" name="update"></center>
                                    </div>
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- The Modal -->
                     <div class="modal fade" id="myModaldel<?php echo $c?>">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <!-- Modal Header -->
                              <div class="modal-header">
                                 <h4 class="modal-title">Are you sure you want to delete theis achiever??</h4>
                                 <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <!-- Modal body -->
                              <div class="modal-body">
                                 <form action="" method="post">
                                    <input type="hidden" name="uid" value="<?php echo $row['uid'];?>">
                                    <input type="submit" value="del" name="del" class="btn btn-danger" >
                                 </form>
                              </div>
                              <!-- Modal footer -->
                              <div class="modal-footer">
                                 <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </tr>
                  <?php
                     }
                     ?>
               </table>
            </div>
         </div>
<!--      </div>-->
<!--   </div>-->
<!--</div>-->
<?php
   if($_POST['update'])
   {
    //   echo $uid;
       
    //   echo $_FILES["fileToUpload"]["name"];
    //   echo " ".$update;
   }
   ?>
<?php include"footer.php";
   ?>